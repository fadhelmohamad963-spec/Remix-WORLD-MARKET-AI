import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { db, EXCHANGE_RATES } from './src/server/db.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini on server-side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// ----------------------------------------------------
// 1. PRODUCTS & PRICING API
// ----------------------------------------------------

app.get('/api/products', (req: Request, res: Response) => {
  try {
    const { search, category, country, city, type, trend, barcode } = req.query;
    const items = db.getProducts({
      search: search ? String(search) : undefined,
      category: category ? String(category) : undefined,
      country: country ? String(country) : undefined,
      city: city ? String(city) : undefined,
      type: type ? (String(type) as any) : undefined,
      trend: trend ? (String(trend) as any) : undefined,
      barcode: barcode ? String(barcode) : undefined,
    });
    res.json({ success: true, count: items.length, products: items });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/products/:id', (req: Request, res: Response) => {
  try {
    const product = db.getProductById(req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, error: 'Product not found' });
    }
    res.json({ success: true, product });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/compare', (req: Request, res: Response) => {
  try {
    const query = req.query.q ? String(req.query.q).toLowerCase() : '';
    const all = db.getProducts();
    const matched = all.filter(
      (p) =>
        p.productId === query ||
        p.barcode === query ||
        p.productNameAr.toLowerCase().includes(query) ||
        p.productNameEn.toLowerCase().includes(query)
    );
    res.json({ success: true, count: matched.length, items: matched, exchangeRates: EXCHANGE_RATES });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/products', (req: Request, res: Response) => {
  try {
    const data = req.body;
    if (!data.productNameAr || !data.retailPrice) {
      return res.status(400).json({ success: false, error: 'اسم المنتج وسعر التجزئة مطلوبان' });
    }
    const created = db.addOrUpdatePrice(data);
    res.json({ success: true, product: created });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Market Movers (price drops, price hikes, most searched)
app.get('/api/market-movers', (_req: Request, res: Response) => {
  try {
    const all = db.getProducts();
    const priceDrops = all
      .filter((p) => p.priceTrend === 'down' || p.changePercentWeekly < 0)
      .sort((a, b) => a.changePercentWeekly - b.changePercentWeekly);

    const priceHikes = all
      .filter((p) => p.priceTrend === 'up' || p.changePercentWeekly > 0)
      .sort((a, b) => b.changePercentWeekly - a.changePercentWeekly);

    const wholesaleDeals = all.filter((p) => p.minWholesaleQty > 1);

    res.json({
      success: true,
      priceDrops: priceDrops.slice(0, 6),
      priceHikes: priceHikes.slice(0, 6),
      wholesaleDeals: wholesaleDeals.slice(0, 6),
      totalProducts: all.length,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ----------------------------------------------------
// 2. BARCODE SCANNER & OPENFOODFACTS INTEGRATION
// ----------------------------------------------------

app.get('/api/barcode/:code', async (req: Request, res: Response) => {
  const barcode = req.params.code.trim();
  try {
    // 1. Check local DB first
    const localMatches = db.getProductsByBarcode(barcode);
    if (localMatches.length > 0) {
      return res.json({
        success: true,
        source: 'local_verified_db',
        barcode,
        matches: localMatches,
        primary: localMatches[0],
      });
    }

    // 2. Query OpenFoodFacts API for international goods
    let externalData = null;
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);
      const response = await fetch(`https://world.openfoodfacts.org/api/v2/product/${barcode}.json`, {
        signal: controller.signal,
        headers: {
          'User-Agent': 'WorldMarketAI - FullStackApp/1.0',
        },
      });
      clearTimeout(timeoutId);

      if (response.ok) {
        const json = await response.json();
        if (json.status === 1 && json.product) {
          const p = json.product;
          externalData = {
            productNameAr: p.product_name_ar || p.product_name || 'منتج عالمي (مسجل عبر الباركود)',
            productNameEn: p.product_name_en || p.product_name || 'Global Barcode Product',
            brand: p.brands || 'ماركة مسجلة',
            barcode,
            packageSize: p.quantity || '1 عبوة',
            category: 'produce',
            imageUrl: p.image_url || p.image_front_url || '',
            ingredients: p.ingredients_text || '',
            nutriscore: p.nutriscore_grade || '',
          };
        }
      }
    } catch {
      // offline / timeout fallback
    }

    if (externalData) {
      return res.json({
        success: true,
        source: 'open_food_facts',
        barcode,
        externalData,
        matches: [],
        message: 'تم العثور على المنتج في السجل العالمي للباركود، يمكنك الآن إضافة عروض الأسعار له.',
      });
    }

    // 3. Not found anywhere
    res.json({
      success: false,
      barcode,
      message: 'الباركود غير مسجل حالياً. يمكنك اقتراح إضافة هذا المنتج وتحديد بياناته وأسعاره.',
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ----------------------------------------------------
// 3. EXCHANGE RATES & DATA SOURCES
// ----------------------------------------------------

app.get('/api/exchange-rates', (_req: Request, res: Response) => {
  res.json({
    success: true,
    base: 'USD',
    rates: EXCHANGE_RATES,
    lastUpdated: new Date().toISOString(),
  });
});

app.get('/api/sources', (_req: Request, res: Response) => {
  const sources = db.getDataSources();
  res.json({ success: true, sources });
});

app.post('/api/sources/:id/sync', (req: Request, res: Response) => {
  const synced = db.triggerSyncSource(req.params.id);
  if (!synced) return res.status(404).json({ success: false, error: 'Source not found' });
  res.json({ success: true, source: synced });
});

// ----------------------------------------------------
// 4. PRICE ALERTS
// ----------------------------------------------------

app.get('/api/alerts', (req: Request, res: Response) => {
  const userId = req.query.userId ? String(req.query.userId) : 'user-customer-demo';
  const alerts = db.getAlerts(userId);
  res.json({ success: true, alerts });
});

app.post('/api/alerts', (req: Request, res: Response) => {
  try {
    const { userId, productId, productName, targetPrice, currency, direction } = req.body;
    if (!productId || !targetPrice) {
      return res.status(400).json({ success: false, error: 'المنتج والسعر المستهدف مطلوبان' });
    }
    const created = db.addAlert({
      userId: userId || 'user-customer-demo',
      productId,
      productName: productName || 'منتج محدد',
      targetPrice: Number(targetPrice),
      currency: currency || 'SAR',
      direction: direction || 'below',
    });
    res.json({ success: true, alert: created });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/alerts/:id', (req: Request, res: Response) => {
  const userId = req.query.userId ? String(req.query.userId) : 'user-customer-demo';
  const deleted = db.deleteAlert(req.params.id, userId);
  res.json({ success: deleted });
});

// ----------------------------------------------------
// 5. AUTHENTICATION & USERS
// ----------------------------------------------------

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'يرجى إدخال البريد الإلكتروني وكلمة المرور' });
  }
  const user = db.getUserByEmail(email);
  if (!user || user.passwordHash !== password) {
    return res.status(401).json({ success: false, error: 'بيانات تسجيل الدخول غير صحيحة' });
  }
  const { passwordHash: _, ...safeUser } = user;
  res.json({ success: true, user: safeUser, token: `jwt-sim-${user.id}-${Date.now()}` });
});

app.post('/api/auth/register', (req: Request, res: Response) => {
  try {
    const { name, email, password, role, country, city, companyName } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ success: false, error: 'جميع الحقول الأساسية مطلوبة' });
    }
    const newUser = db.createUser({
      name,
      email,
      password,
      role: role || 'customer',
      country,
      city,
      companyName,
    });
    const { passwordHash: _, ...safeUser } = newUser;
    res.json({ success: true, user: safeUser, token: `jwt-sim-${newUser.id}-${Date.now()}` });
  } catch (error: any) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.get('/api/auth/users', (_req: Request, res: Response) => {
  const users = db.getUsers().map(({ passwordHash: _, ...u }) => u);
  res.json({ success: true, users });
});

// ----------------------------------------------------
// 6. WORLD WALLET (DEMO BALANCE & TRANSFERS)
// ----------------------------------------------------

app.get('/api/wallet/:userId', (req: Request, res: Response) => {
  try {
    const wallet = db.getWallet(req.params.userId);
    res.json({ success: true, wallet });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/wallet/transfer', (req: Request, res: Response) => {
  try {
    const { senderId, recipientEmail, amount, currency, note } = req.body;
    if (!senderId || !recipientEmail || !amount || amount <= 0) {
      return res.status(400).json({ success: false, error: 'بيانات التحويل غير مكتملة أو غير صالحة' });
    }
    const tx = db.executeTransfer({
      senderId,
      recipientEmail,
      amount: Number(amount),
      currency: currency || 'SAR',
      note: note || '',
    });
    res.json({ success: true, transaction: tx });
  } catch (error: any) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.post('/api/wallet/topup', (req: Request, res: Response) => {
  try {
    const { userId, currency, amount } = req.body;
    const newBal = db.topUpDemoWallet(userId, currency || 'SAR', Number(amount) || 1000);
    res.json({ success: true, balance: newBal });
  } catch (error: any) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// ----------------------------------------------------
// 7. MISLEADING PRICE REPORTS
// ----------------------------------------------------

app.post('/api/reports', (req: Request, res: Response) => {
  try {
    const rep = db.reportMisleadingPrice(req.body);
    res.json({ success: true, report: rep });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/reports', (_req: Request, res: Response) => {
  res.json({ success: true, reports: db.getReports() });
});

// ----------------------------------------------------
// 8. GEMINI AI ASSISTANT (ACTIONS & NATURAL RESPONSES)
// ----------------------------------------------------

app.post('/api/ai/assistant', async (req: Request, res: Response) => {
  const { message, lang = 'ar' } = req.body;
  if (!message) {
    return res.status(400).json({ success: false, error: 'الرسالة مطلوبة' });
  }

  try {
    // Collect snapshot of actual market data to ground the assistant with 100% verified real database facts
    const allProducts = db.getProducts();
    const dataSources = db.getDataSources();
    const systemPrompt = `
You are the intelligent assistant for "WORLD MARKET AI" (سوق العالم الذكي), an advanced global supermarket & food staples price comparison and wholesale platform.
User language preference: ${lang === 'ar' ? 'Arabic' : 'English'}.
Today's Date: 2026-10-31.

CRITICAL INSTRUCTIONS:
1. ONLY provide facts based on real market data. Never invent fake prices or hallucinate unverified stores.
2. If data for a specific country or store is not available in our verified catalog, explain clearly that our current data sources cover Yemen, Saudi Arabia, Egypt, and UAE, and recommend adding or syncing the source.
3. You can execute actions by mentioning relevant products, comparison tables, and wholesale recommendations.
4. Highlight wholesale vs retail differences, minimum order quantities (MOQ), and currency conversions.

CURRENT VERIFIED MARKET CATALOG SNAPSHOT (JSON):
${JSON.stringify(
  allProducts.map((p) => ({
    id: p.id,
    nameAr: p.productNameAr,
    nameEn: p.productNameEn,
    category: p.category,
    brand: p.brand,
    barcode: p.barcode,
    country: p.countryNameAr,
    city: p.city,
    store: p.storeOrSupplier,
    retailPrice: p.retailPrice,
    wholesalePrice: p.wholesalePrice,
    minWholesaleQty: p.minWholesaleQty,
    currency: p.currency,
    trend: p.priceTrend,
    changePercentWeekly: p.changePercentWeekly,
    lastUpdated: p.lastUpdated,
  })),
  null,
  2
)}

CURRENT ACTIVE DATA SOURCES:
${JSON.stringify(dataSources.map((d) => ({ name: d.name, status: d.status, lastSync: d.lastSync })))}

CURRENT CURRENCY RATES (vs USD):
${JSON.stringify(EXCHANGE_RATES)}

Answer the user directly and helpfully. Offer specific actionable recommendations (like price drops, best wholesale deals, or country price differences).
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: message,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    const replyText = response.text || (lang === 'ar' ? 'عذراً، لم أتمكن من الحصول على رد.' : 'Sorry, I could not generate a response.');

    // Look for product matches mentioned in user request for quick action cards in UI
    const lower = message.toLowerCase();
    const relatedProducts = allProducts.filter(
      (p) =>
        lower.includes(p.productNameAr.toLowerCase()) ||
        lower.includes(p.brand.toLowerCase()) ||
        lower.includes(p.category) ||
        (lower.includes('أرز') && p.category === 'grains') ||
        (lower.includes('سكر') && p.category === 'grains') ||
        (lower.includes('زيت') && p.category === 'oils') ||
        (lower.includes('دقيق') && p.category === 'grains') ||
        (lower.includes('حليب') && p.category === 'dairy') ||
        (lower.includes('لحم') && p.category === 'meat') ||
        (lower.includes('دجاج') && p.category === 'meat') ||
        (lower.includes('شاي') && p.category === 'beverages') ||
        (lower.includes('منظف') && p.category === 'cleaning') ||
        (lower.includes('اليمن') && p.countryCode === 'YE') ||
        (lower.includes('السعودية') && p.countryCode === 'SA') ||
        (lower.includes('مصر') && p.countryCode === 'EG')
    );

    res.json({
      success: true,
      reply: replyText,
      suggestedProducts: relatedProducts.slice(0, 4),
    });
  } catch (error: any) {
    console.error('Gemini Assistant Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'فشل الاتصال بالمساعد الذكي',
      reply:
        lang === 'ar'
          ? 'المساعد الذكي متصل حالياً بقاعدة البيانات المحلية. يمكنك فحص إعدادات API في لوحة المطور.'
          : 'AI Assistant is currently operating with local verified database.',
    });
  }
});

// ----------------------------------------------------
// 9. AI DEVELOPER OFFICE & AUTOMATED TESTS
// ----------------------------------------------------

app.post('/api/dev/chat', async (req: Request, res: Response) => {
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ success: false, error: 'Command prompt required' });

  try {
    const devSystemPrompt = `
You are the AI Senior Technical Architect and Lead Engineer inside the "AI Developer Office" of WORLD MARKET AI.
You have deep knowledge of the application architecture:
- Backend: Express TypeScript server (server.ts) with in-memory JSON persistence (db.ts).
- Frontend: React 19, Tailwind CSS v4, Lucide icons, Motion animations.
- Models: Gemini 3.8 Flash via @google/genai SDK.
- Core systems: Multi-tab browser navigation, Barcode scanner (OpenFoodFacts API + DB), Multi-country price comparison, Wholesale-Retail margins, World Wallet demo banking, Price tracking alerts, Automated test suite runner.

When the developer or owner gives an instruction (e.g. "أضف صفحة جديدة لمقارنة أسعار اللحوم", "افحص سبب توقف تحديث الأسعار", "أضف مصدرًا جديدًا للأسعار"):
1. Analyze the technical requirements.
2. Outline exact code files and changes needed.
3. Verify security, performance, and validation boundaries.
4. Give concise, actionable architectural feedback in Arabic/English.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: devSystemPrompt,
      },
    });

    res.json({
      success: true,
      reply: response.text,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Real Automated Test Runner
app.post('/api/dev/run-tests', async (_req: Request, res: Response) => {
  const results = [];
  const startTime = Date.now();

  // Test 1: Database integrity
  const products = db.getProducts();
  results.push({
    testId: 'T1-DB-INTEGRITY',
    name: 'فحص تكامل قاعدة البيانات وتحقق أسعار السلع (Database Integrity & Price Schema)',
    passed: products.length >= 8,
    details: `تم العثور على ${products.length} سلعة مسجلة ببيانات مفصلة (تجزئة، جملة، باركود، مصدر).`,
  });

  // Test 2: Search filter engine
  const riceItems = db.getProducts({ search: 'أرز' });
  results.push({
    testId: 'T2-SEARCH-ENGINE',
    name: 'محرك البحث المتعدد (Multi-parameter Search Matching)',
    passed: riceItems.length > 0,
    details: `البحث عن "أرز" أرجع ${riceItems.length} نتائج صحيحة مطابقة.`,
  });

  // Test 3: Currency exchange calculation
  const sarPerUsd = EXCHANGE_RATES['SAR'];
  const egpPerUsd = EXCHANGE_RATES['EGP'];
  const validRates = sarPerUsd > 0 && egpPerUsd > 0;
  results.push({
    testId: 'T3-CURRENCY-ENGINE',
    name: 'محرك أسعار الصرف وتحويل العملات (FX Conversion Engine)',
    passed: validRates,
    details: `أسعار الصرف نشطة (USD/SAR: ${sarPerUsd}, USD/EGP: ${egpPerUsd}, USD/YER: ${EXCHANGE_RATES['YER']}).`,
  });

  // Test 4: Barcode verification
  const testBarcode = '6281007010214'; // Al Shalan
  const barcodeMatches = db.getProductsByBarcode(testBarcode);
  results.push({
    testId: 'T4-BARCODE-LOOKUP',
    name: 'مطابقة الباركود وقارئ الرموز (Barcode Scanner Engine)',
    passed: barcodeMatches.length > 0,
    details: `فحص الباركود ${testBarcode} نجح وأرجع منتج: ${barcodeMatches[0]?.productNameAr}.`,
  });

  // Test 5: Price alert trigger check
  const alerts = db.getAlerts('user-customer-demo');
  results.push({
    testId: 'T5-PRICE-ALERTS',
    name: 'نظام تنبيهات تغير الأسعار (Price Tracking & Alerts System)',
    passed: Array.isArray(alerts),
    details: `النظام يحتوي على ${alerts.length} تنبيهات نشطة مع فحص تلقائي لتغير الأسعار.`,
  });

  // Test 6: Wallet demo integrity
  const demoWallet = db.getWallet('user-customer-demo');
  results.push({
    testId: 'T6-WALLET-TRANSACTIONS',
    name: 'محفظة WORLD WALLET وسجل المعاملات (Digital Wallet & Ledger)',
    passed: Boolean(demoWallet && demoWallet.balances && demoWallet.transactions),
    details: `المحفظة تعمل برصيد تجريبي موثق وسجل تحويلات نشط (${demoWallet.transactions.length} معاملات).`,
  });

  // Test 7: Gemini AI Connectivity
  let geminiPassed = false;
  let geminiDetails = '';
  try {
    const testAi = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: 'Ping test. Reply with one word: OK',
    });
    geminiPassed = Boolean(testAi.text);
    geminiDetails = `اتصال Gemini 3.8 Flash نشط واستجاب بنجاح في ${Date.now() - startTime}ms.`;
  } catch (err: any) {
    geminiPassed = false;
    geminiDetails = `فحص Gemini: ${err.message || 'مفتاح API غير متوفر أو خطأ في الشبكة'}`;
  }
  results.push({
    testId: 'T7-GEMINI-AI-CONNECTIVITY',
    name: 'اتصال نموذج الذكاء الاصطناعي (Gemini 3.8 Flash Connectivity)',
    passed: geminiPassed,
    details: geminiDetails,
  });

  const totalPassed = results.filter((r) => r.passed).length;
  res.json({
    success: true,
    totalTests: results.length,
    passedCount: totalPassed,
    failedCount: results.length - totalPassed,
    durationMs: Date.now() - startTime,
    results,
  });
});

app.get('/api/dev/system-health', (_req: Request, res: Response) => {
  const mem = process.memoryUsage();
  res.json({
    success: true,
    status: 'healthy',
    uptimeSeconds: Math.floor(process.uptime()),
    nodeVersion: process.version,
    memoryUsageMB: {
      rss: Math.round(mem.rss / 1024 / 1024),
      heapTotal: Math.round(mem.heapTotal / 1024 / 1024),
      heapUsed: Math.round(mem.heapUsed / 1024 / 1024),
    },
    databaseStats: {
      totalProducts: db.getProducts().length,
      totalUsers: db.getUsers().length,
      totalSources: db.getDataSources().length,
      totalReports: db.getReports().length,
    },
    timestamp: new Date().toISOString(),
  });
});

// ----------------------------------------------------
// 10. VITE DEV MIDDLEWARE / STATIC ASSETS
// ----------------------------------------------------

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    // Development mode with Vite middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production mode
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[WORLD MARKET AI] Server running at http://localhost:${PORT}`);
  });
}

startServer();
