import React, { useState, useEffect } from 'react';
import {
  Terminal,
  Play,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCw,
  Cpu,
  Database,
  Activity,
  Code2,
  Send,
  ShieldCheck,
  Server,
  Layers,
  History,
  Lock,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import { DataSourceStatus } from '../types/index.ts';

export const DeveloperOffice: React.FC = () => {
  const { user } = useAuth();
  const { lang } = useLanguage();

  const [activeTab, setActiveTab] = useState<'tests' | 'chat' | 'sources' | 'health' | 'versions'>('tests');
  const [testResults, setTestResults] = useState<any>(null);
  const [runningTests, setRunningTests] = useState(false);
  const [sources, setSources] = useState<DataSourceStatus[]>([]);
  const [systemHealth, setSystemHealth] = useState<any>(null);
  const [devPrompt, setDevPrompt] = useState('');
  const [devChatHistory, setDevChatHistory] = useState<Array<{ sender: 'dev' | 'ai'; text: string; time: string }>>([
    {
      sender: 'ai',
      text: 'مرحباً بك في مكتب المطور الذكي (AI Developer Office). يمكنك إصدار الأوامر البرمجية، تشغيل حزم الاختبار، فحص تكامل قواعد البيانات، وإدارة مصادر تحديث الأسعار.',
      time: '10:00',
    },
  ]);
  const [loadingChat, setLoadingChat] = useState(false);

  // Check access authorization
  const isAuthorized = user?.role === 'owner' || user?.role === 'admin';

  const fetchSources = async () => {
    try {
      const res = await fetch('/api/sources');
      const data = await res.json();
      if (data.success) setSources(data.sources);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchHealth = async () => {
    try {
      const res = await fetch('/api/dev/system-health');
      const data = await res.json();
      if (data.success) setSystemHealth(data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchSources();
    fetchHealth();
  }, []);

  const runAutomatedTests = async () => {
    setRunningTests(true);
    try {
      const res = await fetch('/api/dev/run-tests', { method: 'POST' });
      const data = await res.json();
      setTestResults(data);
    } catch (e) {
      console.error('Test run failed', e);
    } finally {
      setRunningTests(false);
    }
  };

  const handleDevCommand = async (commandText?: string) => {
    const cmd = (commandText || devPrompt).trim();
    if (!cmd || loadingChat) return;

    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setDevChatHistory((prev) => [...prev, { sender: 'dev', text: cmd, time }]);
    setDevPrompt('');
    setLoadingChat(true);

    try {
      const res = await fetch('/api/dev/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: cmd }),
      });
      const data = await res.json();
      setDevChatHistory((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: data.reply || 'تم تنفيذ الأمر المعماري بنجاح.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (e: any) {
      setDevChatHistory((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: `فشل معالجة الأمر: ${e.message}`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoadingChat(false);
    }
  };

  const handleSyncSource = async (id: string) => {
    try {
      await fetch(`/api/sources/${id}/sync`, { method: 'POST' });
      await fetchSources();
    } catch (e) {
      console.error(e);
    }
  };

  if (!isAuthorized) {
    return (
      <div className="p-8 max-w-xl mx-auto my-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl text-center space-y-4">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          منطقة محظورة - مكتب المطور الذكي (AI Developer Office)
        </h2>
        <p className="text-xs text-slate-500 leading-relaxed">
          هذا القسم مخصص حصرياً لمالك النظام (Owner) والمهندسين المخولين لمراقبة الكود، تشغيل الاختبارات، وتعديل مصادر البيانات.
        </p>
        <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs text-slate-700 dark:text-slate-300">
          يمكنك تبديل دور المستخدم إلى <strong className="text-emerald-500">«المالك والمطور»</strong> من القائمة العلوية لاختبار المنظومة بالكامل.
        </div>
      </div>
    );
  }

  const sampleCommands = [
    'أضف صفحة جديدة لمقارنة أسعار اللحوم',
    'أصلح الخطأ في صفحة المنتجات',
    'أضف اللغة الإنجليزية',
    'حسّن سرعة البحث',
    'افحص سبب توقف تحديث الأسعار',
    'أضف مصدرًا جديدًا للأسعار',
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Dev Header */}
      <div className="bg-slate-950 text-white rounded-3xl p-6 border border-slate-800 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 end-0 p-8 opacity-10 pointer-events-none">
          <Terminal className="w-48 h-48 text-emerald-500" />
        </div>

        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shadow-lg">
              <Terminal className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-extrabold tracking-wide font-mono">
                  AI DEVELOPER OFFICE
                </h1>
                <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-500/30 text-emerald-400 rounded-full font-bold">
                  v2.4.0-PROD
                </span>
              </div>
              <p className="text-xs text-slate-400">
                مركز التحكم الهندسي واختبار وتطوير تطبيق WORLD MARKET AI
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={runAutomatedTests}
            disabled={runningTests}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all"
          >
            <Play className={`w-4 h-4 ${runningTests ? 'animate-spin' : ''}`} />
            <span>{runningTests ? 'جاري تنفيذ الاختبارات...' : 'تشغيل الاختبارات الآلية الشاملة'}</span>
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 mt-6 border-t border-slate-800/80 pt-4 overflow-x-auto no-scrollbar text-xs">
          {[
            { id: 'tests', label: 'حزمة الاختبارات الآلية (Test Suite)', icon: Play },
            { id: 'chat', label: 'مساعد البرمجة الذكي (Dev AI Chat)', icon: Code2 },
            { id: 'sources', label: 'مصادر البيانات والأسعار (Data Sources)', icon: Database },
            { id: 'health', label: 'مؤشرات النظام والخادم (System Health)', icon: Cpu },
            { id: 'versions', label: 'سجل الإصدارات (Version Log)', icon: History },
          ].map((tab) => {
            const Icon = tab.icon;
            const isTabActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition-all ${
                  isTabActive
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-xs'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 1. Automated Tests Tab */}
      {activeTab === 'tests' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                نتائج حزم الاختبار والتحقق الفعلي (Automated Backend Asserts)
              </h3>
              <p className="text-xs text-slate-500">
                اختبارات فعلية يتم تشغيلها ومطابقتها على الخادم وقاعدة البيانات
              </p>
            </div>
            {testResults && (
              <span
                className={`px-3 py-1 text-xs font-bold rounded-full ${
                  testResults.failedCount === 0
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                }`}
              >
                {testResults.passedCount} / {testResults.totalTests} اختبارات ناجحة ({testResults.durationMs}ms)
              </span>
            )}
          </div>

          {!testResults && (
            <div className="text-center py-10 space-y-3">
              <Activity className="w-10 h-10 text-slate-400 mx-auto" />
              <p className="text-xs text-slate-500">
                انقر على زر "تشغيل الاختبارات الآلية الشاملة" لتنفيذ الفحص الفعلي لكافة مسارات النظام.
              </p>
              <button
                type="button"
                onClick={runAutomatedTests}
                className="px-4 py-2 bg-slate-900 dark:bg-emerald-600 text-white text-xs font-bold rounded-xl"
              >
                بدء الاختبار الآن
              </button>
            </div>
          )}

          {testResults && (
            <div className="space-y-2">
              {testResults.results.map((r: any) => (
                <div
                  key={r.testId}
                  className={`p-3 rounded-xl border flex items-start gap-3 transition-colors ${
                    r.passed
                      ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-500/20'
                      : 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-500/20'
                  }`}
                >
                  {r.passed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900 dark:text-slate-100 font-mono">
                        [{r.testId}] {r.name}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                          r.passed ? 'bg-emerald-500/20 text-emerald-600' : 'bg-rose-500/20 text-rose-600'
                        }`}
                      >
                        {r.passed ? 'PASSED' : 'FAILED'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{r.details}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. Dev AI Chat Tab */}
      {activeTab === 'chat' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              المحادثة الهندسية وتطوير المعمارية (AI Engineering Terminal)
            </h3>
            <p className="text-xs text-slate-500">
              أصدر أوامر التطوير البرمجي وتعديل الملفات مع مراجعة الإجراءات الفنية
            </p>
          </div>

          {/* Quick command buttons */}
          <div className="flex flex-wrap gap-1.5">
            {sampleCommands.map((cmd, i) => (
              <button
                key={i}
                type="button"
                onClick={() => handleDevCommand(cmd)}
                className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-slate-700 dark:text-slate-300 hover:text-emerald-500 text-xs rounded-lg border border-slate-200 dark:border-slate-700 font-mono"
              >
                «{cmd}»
              </button>
            ))}
          </div>

          {/* Chat Stream */}
          <div className="h-80 overflow-y-auto bg-slate-950 text-slate-100 p-4 rounded-2xl border border-slate-800 space-y-3 font-mono text-xs">
            {devChatHistory.map((item, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-xl ${
                  item.sender === 'dev'
                    ? 'bg-slate-900 border border-slate-800 text-emerald-400'
                    : 'bg-slate-900/60 border border-slate-800/60 text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                  <span>{item.sender === 'dev' ? '🔧 ARCHITECT / OWNER' : '🤖 AI DEV LEAD (Gemini 3.8 Flash)'}</span>
                  <span>{item.time}</span>
                </div>
                <div className="whitespace-pre-line leading-relaxed">{item.text}</div>
              </div>
            ))}
            {loadingChat && (
              <div className="text-emerald-400 flex items-center gap-2">
                <RotateCw className="w-3.5 h-3.5 animate-spin" />
                <span>جاري تحليل الكود وصياغة التعديل الهندسي...</span>
              </div>
            )}
          </div>

          {/* Prompt input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleDevCommand();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={devPrompt}
              onChange={(e) => setDevPrompt(e.target.value)}
              placeholder="اكتب أمر المطور هنا..."
              className="flex-1 px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl text-xs font-mono focus:outline-none focus:border-emerald-500"
            />
            <button
              type="submit"
              disabled={loadingChat || !devPrompt.trim()}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>إرسال</span>
            </button>
          </form>
        </div>
      )}

      {/* 3. Data Sources Monitor */}
      {activeTab === 'sources' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                لوحة مراقبة مصادر وتغذيات الأسعار (Live Data Sources)
              </h3>
              <p className="text-xs text-slate-500">
                تتبع حالة واجهات API، وسجلات الغرف التجارية، ومعدلات الأخطاء وزمن الاستجابة
              </p>
            </div>
            <button
              type="button"
              onClick={fetchSources}
              className="p-2 text-slate-400 hover:text-emerald-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <RotateCw className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {sources.map((src) => (
              <div
                key={src.id}
                className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">
                    {src.name}
                  </span>
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    {src.status.toUpperCase()}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-[11px] pt-1 border-t border-slate-200 dark:border-slate-700/50">
                  <div>
                    <span className="text-slate-400 block">السجلات</span>
                    <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                      {src.recordsCount.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">زمن الاستجابة</span>
                    <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                      {src.latencyMs} ms
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">معدل الخطأ</span>
                    <span className="font-mono font-bold text-emerald-500">
                      {(src.errorRate * 100).toFixed(1)}%
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <span>آخر مزامنة: {src.lastSync.slice(11, 19)}</span>
                  <button
                    type="button"
                    onClick={() => handleSyncSource(src.id)}
                    className="px-2 py-0.5 bg-slate-200 dark:bg-slate-700 hover:bg-emerald-500 hover:text-white rounded text-slate-700 dark:text-slate-200 transition-colors"
                  >
                    مزامنة فورية الآن
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. System Health Tab */}
      {activeTab === 'health' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              المؤشرات التقنية وموارد الخادم
            </h3>
            <p className="text-xs text-slate-500">
              متابعة استهلاك الذاكرة وحالة بيئة التشغيل
            </p>
          </div>

          {systemHealth && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
                <Cpu className="w-5 h-5 mx-auto text-emerald-500 mb-1" />
                <span className="text-xs text-slate-400 block">استهلاك الذاكرة (RSS)</span>
                <span className="text-lg font-mono font-bold text-slate-900 dark:text-slate-100">
                  {systemHealth.memoryUsageMB?.rss} MB
                </span>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
                <Database className="w-5 h-5 mx-auto text-sky-500 mb-1" />
                <span className="text-xs text-slate-400 block">السلع المسجلة</span>
                <span className="text-lg font-mono font-bold text-slate-900 dark:text-slate-100">
                  {systemHealth.databaseStats?.totalProducts}
                </span>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
                <Server className="w-5 h-5 mx-auto text-amber-500 mb-1" />
                <span className="text-xs text-slate-400 block">مدة تشغيل الخادم</span>
                <span className="text-lg font-mono font-bold text-slate-900 dark:text-slate-100">
                  {Math.floor(systemHealth.uptimeSeconds / 60)} دقيقة
                </span>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800 text-center">
                <ShieldCheck className="w-5 h-5 mx-auto text-teal-500 mb-1" />
                <span className="text-xs text-slate-400 block">إصدار Node.js</span>
                <span className="text-lg font-mono font-bold text-slate-900 dark:text-slate-100">
                  {systemHealth.nodeVersion}
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 5. Version Changelog Tab */}
      {activeTab === 'versions' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              سجل الإصدارات والتحديثات المعمارية
            </h3>
            <p className="text-xs text-slate-500">
              تاريخ بناء وتطوير تطبيق WORLD MARKET AI
            </p>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400 font-bold mb-1">
                <span>الإصدار v2.4.0 (الإطلاق الحالي - 31 أكتوبر 2026)</span>
                <span className="text-[10px] bg-emerald-500/10 px-2 py-0.5 rounded">CURRENT</span>
              </div>
              <ul className="list-disc list-inside text-slate-600 dark:text-slate-300 space-y-1 font-sans">
                <li>ربط محرك Gemini 3.8 Flash عبر سيرفر Express الآمن مع أدوات التنفيذ الفعلي.</li>
                <li>تفعيل قارئ الباركود مع كاميرا HTML5 وربط سجل OpenFoodFacts العالمي.</li>
                <li>إطلاق محفظة WORLD WALLET بنظام الإيصالات الرقمية المشفرة والرصيد التجريبي.</li>
                <li>نظام المقارنة العالمية الموحدة لأسعار الصرف (SAR, YER, EGP, AED, USD).</li>
                <li>لوحة مكتب المطور الذكي وحزمة الاختبارات الآلية الشاملة.</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
