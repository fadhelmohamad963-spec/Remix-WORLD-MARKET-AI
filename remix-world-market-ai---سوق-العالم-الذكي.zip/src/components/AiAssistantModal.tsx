import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Bot,
  Send,
  Sparkles,
  Search,
  Scale,
  TrendingDown,
  Building2,
  Bell,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';
import { ProductPrice } from '../types/index.ts';
import { useLanguage } from '../contexts/LanguageContext.tsx';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  suggestedProducts?: ProductPrice[];
  timestamp: string;
}

interface AiAssistantModalProps {
  onClose: () => void;
  onSelectProduct: (p: ProductPrice) => void;
  onOpenCompare: (p: ProductPrice) => void;
  onOpenAlert: (p: ProductPrice) => void;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({
  onClose,
  onSelectProduct,
  onOpenCompare,
  onOpenAlert,
}) => {
  const { lang, t } = useLanguage();
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm-welcome',
      sender: 'assistant',
      text:
        lang === 'ar'
          ? 'مرحباً بك في المساعد الذكي لـ WORLD MARKET AI! أنا متصل مباشرة بمحرك البحث العالمي وقاعدة بيانات أسعار السوبرماركت والجملة والتجزئة. يمكنك أن تطلب مني البحث في اليمن، السعودية، مصر، أو مقارنة أسعار أي سلعة غذائية واكتشاف الموردين.'
          : 'Welcome to WORLD MARKET AI Assistant! I am directly connected to the global price engine, wholesale suppliers, and retail databases. Ask me to find prices in Yemen, Saudi Arabia, Egypt, compare staples, or find bulk suppliers.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const sendMessage = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: query, lang }),
      });
      const data = await res.json();

      const botMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text: data.reply || (lang === 'ar' ? 'تمت معالجة طلبك بنجاح.' : 'Processed your request.'),
        suggestedProducts: data.suggestedProducts || [],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `bot-err-${Date.now()}`,
          sender: 'assistant',
          text: lang === 'ar' ? 'حدث خطأ أثناء التواصل مع المحرك الذكي.' : 'Error contacting AI engine.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    { ar: 'ابحث عن سعر الأرز في اليمن اليوم', en: 'Search rice price in Yemen today' },
    { ar: 'قارن أسعار السكر في اليمن والسعودية ومصر', en: 'Compare sugar prices in Yemen, Saudi and Egypt' },
    { ar: 'ابحث عن موردين يبيعون زيت الطبخ بالجملة', en: 'Find wholesale cooking oil suppliers' },
    { ar: 'اعرض المنتجات التي انخفضت أسعارها خلال أسبوع', en: 'Show products with price drops this week' },
    { ar: 'أنشئ تقريرًا عن تغير أسعار السلع الأساسية', en: 'Generate report on staple food price changes' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-3xl h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-emerald-600/10 via-teal-600/5 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-md">
              <Bot className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  مساعد WORLD MARKET AI الذكي
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold rounded-full">
                  Gemini 3.8 Flash
                </span>
              </div>
              <p className="text-xs text-slate-500">
                مربوط مباشرة بمحرك البحث وأدوات التنفيذ الحقيقية لقواعد بيانات الأسواق
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Pills */}
        <div className="px-4 py-2 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar text-xs">
          <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
          {samplePrompts.map((p, i) => (
            <button
              key={i}
              type="button"
              onClick={() => sendMessage(lang === 'ar' ? p.ar : p.en)}
              className="px-2.5 py-1 bg-white dark:bg-slate-900 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-slate-700 dark:text-slate-300 hover:text-emerald-600 rounded-full border border-slate-200 dark:border-slate-800 shrink-0 transition-colors shadow-2xs font-medium"
            >
              {lang === 'ar' ? p.ar : p.en}
            </button>
          ))}
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-emerald-600 text-white rounded-br-none shadow-md'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-slate-700/60 shadow-xs'
                }`}
              >
                <div className="whitespace-pre-line">{msg.text}</div>

                {/* Interactive Product Cards Rendered in Chat */}
                {msg.suggestedProducts && msg.suggestedProducts.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-300 dark:border-slate-700 space-y-2">
                    <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 block">
                      السلع المطابقة الموثقة في قاعدة البيانات:
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {msg.suggestedProducts.map((prod) => (
                        <div
                          key={prod.id}
                          className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between"
                        >
                          <div>
                            <p className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">
                              {prod.productNameAr}
                            </p>
                            <p className="text-[10px] text-slate-500">
                              {prod.storeOrSupplier} • {prod.countryNameAr}
                            </p>
                            <div className="mt-1 flex items-baseline gap-1.5">
                              <span className="text-xs font-bold text-emerald-600">
                                {prod.retailPrice} {prod.currency} (تجزئة)
                              </span>
                              <span className="text-[10px] text-amber-600">
                                جملة: {prod.wholesalePrice}
                              </span>
                            </div>
                          </div>
                          <div className="mt-2 flex gap-1">
                            <button
                              type="button"
                              onClick={() => {
                                onSelectProduct(prod);
                                onClose();
                              }}
                              className="flex-1 py-1 px-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold rounded"
                            >
                              عرض السلعة
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                onOpenCompare(prod);
                                onClose();
                              }}
                              className="py-1 px-1.5 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[10px] rounded"
                            >
                              مقارنة
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div
                  className={`mt-1.5 text-[10px] ${
                    msg.sender === 'user' ? 'text-emerald-200' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 p-3 bg-slate-100 dark:bg-slate-800 rounded-2xl w-fit text-xs text-slate-500">
              <Bot className="w-4 h-4 text-emerald-500 animate-spin" />
              <span>جاري استرجاع الأسعار وتحليل الأسواق...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input Bar */}
        <div className="p-3 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage();
            }}
            className="flex items-center gap-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-2xl p-1.5 focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="اطلب أي معلومة أو مقارنة، مثل: قارن أسعار السكر بين اليمن والسعودية..."
              className="flex-1 px-3 py-1.5 bg-transparent text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="p-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-xl transition-all shadow"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
