import React from 'react';
import {
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  Minus,
  Scale,
  Bell,
  LineChart,
  ExternalLink,
  Store,
  Building2,
  PackageCheck,
  AlertTriangle,
} from 'lucide-react';
import { ProductPrice } from '../types/index.ts';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import { useBrowser } from '../contexts/BrowserContext.tsx';

interface ProductCardProps {
  product: ProductPrice;
  onOpenCompare: (p: ProductPrice) => void;
  onOpenHistory: (p: ProductPrice) => void;
  onOpenAlert: (p: ProductPrice) => void;
  onReportMisleading: (p: ProductPrice) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onOpenCompare,
  onOpenHistory,
  onOpenAlert,
  onReportMisleading,
}) => {
  const { lang, t } = useLanguage();
  const { selectedCurrency } = useBrowser();

  // Unit price calculation (e.g. per kg or liter)
  const unitFactor = product.weightGramsOrMl > 0 ? product.weightGramsOrMl / 1000 : 1;
  const unitPricePerKgOrLiter = (product.retailPrice / unitFactor).toFixed(2);
  const wholesaleDiscountPct = Math.round(
    ((product.retailPrice - product.wholesalePrice) / product.retailPrice) * 100
  );

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs hover:shadow-xl hover:border-emerald-500/40 transition-all flex flex-col justify-between group">
      <div>
        {/* Top Image & Badges */}
        <div className="relative h-44 w-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
          <img
            src={product.imageUrl}
            alt={product.productNameAr}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />

          {/* Trend Badge */}
          <div className="absolute top-2.5 start-2.5 flex items-center gap-1">
            {product.priceTrend === 'down' && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-600 text-white shadow-sm">
                <TrendingDown className="w-3.5 h-3.5" />
                {product.changePercentWeekly}%
              </span>
            )}
            {product.priceTrend === 'up' && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-600 text-white shadow-sm">
                <TrendingUp className="w-3.5 h-3.5" />
                +{product.changePercentWeekly}%
              </span>
            )}
            {product.priceTrend === 'stable' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-800/80 text-slate-200 backdrop-blur-xs">
                <Minus className="w-3 h-3" />
                مستقر
              </span>
            )}
          </div>

          {/* Country & Verification Badge */}
          <div className="absolute top-2.5 end-2.5 flex items-center gap-1.5">
            {product.verified && (
              <span
                className="p-1 bg-white/90 dark:bg-slate-900/90 text-emerald-500 rounded-full shadow-xs"
                title={t.verifiedSource}
              >
                <ShieldCheck className="w-4 h-4" />
              </span>
            )}
            <span className="px-2 py-0.5 bg-slate-900/80 text-white text-[11px] font-bold rounded-md backdrop-blur-xs shadow-xs">
              {product.countryCode === 'SA' ? '🇸🇦 السعودية' : product.countryCode === 'YE' ? '🇾🇪 اليمن' : product.countryCode === 'EG' ? '🇪🇬 مصر' : '🇦🇪 الإمارات'}
            </span>
          </div>

          {/* Barcode Overlay Pill */}
          <div className="absolute bottom-2 start-2 bg-slate-950/80 text-slate-300 px-2 py-0.5 rounded text-[10px] font-mono tracking-wider backdrop-blur-xs">
            EAN: {product.barcode}
          </div>
        </div>

        {/* Card Body */}
        <div className="p-4 space-y-3">
          <div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mb-1">
              <span className="font-semibold text-emerald-600 dark:text-emerald-400">{product.brand}</span>
              <span>{product.packageSize}</span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 leading-snug line-clamp-2">
              {lang === 'ar' ? product.productNameAr : product.productNameEn}
            </h3>
          </div>

          {/* Store / Supplier info */}
          <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-2 rounded-lg">
            {product.supplierType === 'supermarket' ? (
              <Store className="w-4 h-4 text-sky-500 shrink-0" />
            ) : (
              <Building2 className="w-4 h-4 text-amber-500 shrink-0" />
            )}
            <div className="truncate">
              <span className="font-semibold">{product.storeOrSupplier}</span>
              <span className="text-[11px] text-slate-400 ms-1">({product.city})</span>
            </div>
          </div>

          {/* Pricing Grid */}
          <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100 dark:border-slate-800">
            {/* Retail */}
            <div className="bg-emerald-500/5 dark:bg-emerald-500/10 p-2 rounded-xl">
              <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium block">
                {t.retail} (قطاعي)
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-base font-extrabold text-emerald-700 dark:text-emerald-300">
                  {product.retailPrice.toLocaleString()}
                </span>
                <span className="text-[10px] font-bold text-emerald-600">{product.currency}</span>
              </div>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                ~ {unitPricePerKgOrLiter} {product.currency}/كجم
              </span>
            </div>

            {/* Wholesale */}
            <div className="bg-amber-500/5 dark:bg-amber-500/10 p-2 rounded-xl border border-amber-500/20">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold">
                  {t.wholesale} (بالكمية)
                </span>
                {wholesaleDiscountPct > 0 && (
                  <span className="text-[9px] bg-amber-500 text-white font-bold px-1 rounded">
                    -{wholesaleDiscountPct}%
                  </span>
                )}
              </div>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-base font-extrabold text-amber-600 dark:text-amber-400">
                  {product.wholesalePrice.toLocaleString()}
                </span>
                <span className="text-[10px] font-bold text-amber-500">{product.currency}</span>
              </div>
              <span className="text-[10px] text-slate-400 block mt-0.5 truncate">
                أقل كمية: {product.minWholesaleQty} {product.wholesaleUnit}
              </span>
            </div>
          </div>

          {/* Source Link & Verification Info */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
            <span className="truncate max-w-[170px]" title={product.sourceName}>
              المصدر: {product.sourceName}
            </span>
            <span className="shrink-0">{product.lastUpdated.slice(0, 10)}</span>
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="p-3 bg-slate-50 dark:bg-slate-950/60 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-1.5">
        <button
          type="button"
          onClick={() => onOpenCompare(product)}
          className="flex-1 flex items-center justify-center gap-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors shadow-xs"
          title="مقارنة بين البلدان والمتاجر"
        >
          <Scale className="w-3.5 h-3.5" />
          <span>مقارنة عالمية</span>
        </button>

        <button
          type="button"
          onClick={() => onOpenHistory(product)}
          className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-emerald-500 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors"
          title="الرسم البياني لتغير السعر"
        >
          <LineChart className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => onOpenAlert(product)}
          className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-amber-500 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors"
          title="تفعيل تنبيه عند انخفاض السعر"
        >
          <Bell className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={() => onReportMisleading(product)}
          className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors"
          title="إبلاغ عن سعر غير دقيق"
        >
          <AlertTriangle className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
