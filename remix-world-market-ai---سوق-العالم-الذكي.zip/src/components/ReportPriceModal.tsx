import React, { useState } from 'react';
import { X, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { ProductPrice } from '../types/index.ts';

interface ReportPriceModalProps {
  product: ProductPrice | null;
  onClose: () => void;
}

export const ReportPriceModal: React.FC<ReportPriceModalProps> = ({ product, onClose }) => {
  if (!product) return null;

  const [reason, setReason] = useState('السعر في المتجر الفعلي أعلى من السعر المعروض هنا');
  const [claimedPrice, setClaimedPrice] = useState(String(product.retailPrice * 1.15));
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          priceId: product.id,
          productName: product.productNameAr,
          reportedBy: 'user-demo@market.ai',
          reason,
          reportedPrice: product.retailPrice,
          claimedActualPrice: Number(claimedPrice),
        }),
      });
      setSubmitted(true);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-rose-500/10 text-rose-500 rounded-xl">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              الإبلاغ عن سعر غير دقيق أو مضلل
            </h3>
          </div>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="text-center py-6 space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
            <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
              شكراً لحرصك على نزاهة الأسعار!
            </p>
            <p className="text-xs text-slate-500">
              تم تحويل البلاغ إلى فريق التدقيق للمطابقة مع فاتورة المورد وفحص الرابط المباشر.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-900 dark:bg-slate-800 text-white text-xs font-bold rounded-xl"
            >
              إغلاق
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3 text-xs">
            <div>
              <span className="text-slate-400 block">السلعة:</span>
              <p className="font-bold text-slate-800 dark:text-slate-200">{product.productNameAr}</p>
              <span className="text-[11px] text-slate-500">
                السعر الحالي المسجل: {product.retailPrice} {product.currency} في {product.storeOrSupplier}
              </span>
            </div>

            <div>
              <label className="font-semibold block mb-1">سبب البلاغ:</label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
              >
                <option value="السعر في المتجر الفعلي أعلى من السعر المعروض هنا">
                  السعر في المتجر الفعلي أعلى من السعر المعروض هنا
                </option>
                <option value="المنتج غير متوفر (نفاد الكمية في المتجر)">
                  المنتج غير متوفر (نفاد الكمية في المتجر)
                </option>
                <option value="الوزن أو حجم العبوة مختلف عن الموصوف">
                  الوزن أو حجم العبوة مختلف عن الموصوف
                </option>
                <option value="العرض انتهى صلاحيته">العرض انتهى صلاحيته</option>
              </select>
            </div>

            <div>
              <label className="font-semibold block mb-1">السعر الفعلي الذي وجدته بالمحل:</label>
              <input
                type="number"
                required
                value={claimedPrice}
                onChange={(e) => setClaimedPrice(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl transition-all shadow"
            >
              {loading ? 'جاري الإرسال...' : 'إرسال البلاغ للتدقيق'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
