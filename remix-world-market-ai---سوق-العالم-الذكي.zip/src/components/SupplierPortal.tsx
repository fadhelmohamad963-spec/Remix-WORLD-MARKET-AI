import React, { useState } from 'react';
import { Building2, Plus, CheckCircle2, ShieldCheck, AlertCircle, Package } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';

interface SupplierPortalProps {
  onProductAdded?: () => void;
}

export const SupplierPortal: React.FC<SupplierPortalProps> = ({ onProductAdded }) => {
  const { user } = useAuth();
  const { lang } = useLanguage();

  const [productNameAr, setProductNameAr] = useState('');
  const [productNameEn, setProductNameEn] = useState('');
  const [brand, setBrand] = useState('');
  const [category, setCategory] = useState<'grains' | 'oils' | 'dairy' | 'meat' | 'produce' | 'canned' | 'beverages' | 'cleaning' | 'spices'>('grains');
  const [barcode, setBarcode] = useState('');
  const [packageSize, setPackageSize] = useState('10 كجم (كرتون)');
  const [weightGramsOrMl, setWeightGramsOrMl] = useState('10000');
  const [countryCode, setCountryCode] = useState('SA');
  const [city, setCity] = useState('الرياض');
  const [storeOrSupplier, setStoreOrSupplier] = useState(user?.companyName || 'مؤسسة التوريد المعتمدة');
  const [retailPrice, setRetailPrice] = useState('');
  const [wholesalePrice, setWholesalePrice] = useState('');
  const [minWholesaleQty, setMinWholesaleQty] = useState('10');
  const [wholesaleUnit, setWholesaleUnit] = useState('كرتون / عبوة');
  const [currency, setCurrency] = useState<'SAR' | 'YER' | 'EGP' | 'AED' | 'USD'>('SAR');
  const [shippingCost, setShippingCost] = useState('0');
  const [terms, setTerms] = useState('تسليم المستودع / شحن لجميع المحافظات خلال 48 ساعة');
  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80');

  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg('');
    setErrorMsg('');
    setSubmitting(true);

    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productNameAr,
          productNameEn: productNameEn || productNameAr,
          brand,
          category,
          barcode: barcode || `${Math.floor(100000000000 + Math.random() * 900000000000)}`,
          packageSize,
          weightGramsOrMl: Number(weightGramsOrMl) || 1000,
          countryCode,
          countryNameAr: countryCode === 'SA' ? 'المملكة العربية السعودية' : countryCode === 'YE' ? 'اليمن' : countryCode === 'EG' ? 'مصر' : 'الإمارات',
          countryNameEn: countryCode === 'SA' ? 'Saudi Arabia' : countryCode === 'YE' ? 'Yemen' : countryCode === 'EG' ? 'Egypt' : 'UAE',
          city,
          storeOrSupplier,
          supplierType: 'wholesaler',
          retailPrice: Number(retailPrice),
          wholesalePrice: Number(wholesalePrice) || Number(retailPrice) * 0.9,
          minWholesaleQty: Number(minWholesaleQty) || 5,
          wholesaleUnit,
          currency,
          shippingCost: Number(shippingCost) || 0,
          sourceName: `عرض مسجل من التاجر: ${storeOrSupplier}`,
          sourceUrl: '#',
          verified: true,
          imageUrl,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg('تم إدراج عرض الجملة والسلعة بنجاح وتحديث قاعدة البيانات العالمية!');
        setProductNameAr('');
        setRetailPrice('');
        setWholesalePrice('');
        if (onProductAdded) onProductAdded();
      } else {
        setErrorMsg(data.error || 'فشل إضافة المنتج');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'خطأ في الاتصال بالخادم');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Supplier Banner */}
      <div className="bg-gradient-to-r from-amber-600/10 via-amber-500/5 to-transparent border border-amber-500/30 rounded-3xl p-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-500 border border-amber-500/30 flex items-center justify-center">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                بوابة الموردين والتجار (B2B Wholesale Portal)
              </h2>
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-mono text-[10px] font-bold rounded-full">
                VERIFIED SUPPLIER
              </span>
            </div>
            <p className="text-xs text-slate-500">
              أضف عروض الجملة، حدد الحد الأدنى للكميات (MOQ)، ومناطق الشحن وشروط البيع
            </p>
          </div>
        </div>
      </div>

      {/* Form Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 border-b border-slate-200 dark:border-slate-800 pb-3 flex items-center gap-2">
          <Package className="w-4 h-4 text-emerald-500" />
          تسجيل دفعة أو سلعة غذائية جديدة بسعر الجملة والتجزئة
        </h3>

        {successMsg && (
          <div className="p-3 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-xs rounded-xl flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {errorMsg && (
          <div className="p-3 bg-rose-500/10 text-rose-600 text-xs rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="font-semibold block mb-1">اسم السلعة (بالعربية):</label>
              <input
                type="text"
                required
                placeholder="مثال: أرز بسمتي هندي درجة أولى 10 كجم"
                value={productNameAr}
                onChange={(e) => setProductNameAr(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">العلامة التجارية (الماركة):</label>
              <input
                type="text"
                required
                placeholder="مثال: الشعلان، عافية، المراعي، أو اسم المصنع"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">القسم والتصنيف:</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-medium"
              >
                <option value="grains">الحبوب والأرز والدقيق والسكر</option>
                <option value="oils">زيوت الطبخ والسمن</option>
                <option value="dairy">الألبان والحليب والأجبان</option>
                <option value="meat">اللحوم والدواجن</option>
                <option value="cleaning">المنظفات ومستلزمات النظافة</option>
                <option value="beverages">الشاي والقهوة والمشروبات</option>
                <option value="canned">المعلبات</option>
              </select>
            </div>

            <div>
              <label className="font-semibold block mb-1">رمز الباركود الدولي (EAN/UPC):</label>
              <input
                type="text"
                placeholder="اختياري - سيتم توليد رمز فريد إذا تُرك فارغاً"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">حجم العبوة والوزن الصافي:</label>
              <input
                type="text"
                required
                placeholder="مثال: 10 كجم خيشة أو كرتون 12 لتر"
                value={packageSize}
                onChange={(e) => setPackageSize(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">البلد والمدينة:</label>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={countryCode}
                  onChange={(e) => setCountryCode(e.target.value)}
                  className="px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
                >
                  <option value="SA">المملكة العربية السعودية</option>
                  <option value="YE">اليمن</option>
                  <option value="EG">مصر</option>
                  <option value="AE">الإمارات</option>
                </select>
                <input
                  type="text"
                  placeholder="المدينة (الرياض، عدن، صنعاء...)"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
                />
              </div>
            </div>

            {/* Pricing Details */}
            <div className="bg-emerald-500/5 dark:bg-emerald-500/10 p-3 rounded-2xl border border-emerald-500/20">
              <label className="font-bold text-emerald-700 dark:text-emerald-400 block mb-1">
                سعر التجزئة المقترح (قطاعي):
              </label>
              <input
                type="number"
                required
                placeholder="مثال: 85"
                value={retailPrice}
                onChange={(e) => setRetailPrice(e.target.value)}
                className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-mono text-sm font-bold text-emerald-600"
              />
            </div>

            <div className="bg-amber-500/5 dark:bg-amber-500/10 p-3 rounded-2xl border border-amber-500/20">
              <label className="font-bold text-amber-700 dark:text-amber-400 block mb-1">
                سعر الجملة للكميات (Wholesale Price):
              </label>
              <input
                type="number"
                required
                placeholder="مثال: 72"
                value={wholesalePrice}
                onChange={(e) => setWholesalePrice(e.target.value)}
                className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-mono text-sm font-bold text-amber-600"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">الحد الأدنى لطلب الجملة (MOQ):</label>
              <input
                type="number"
                required
                placeholder="10"
                value={minWholesaleQty}
                onChange={(e) => setMinWholesaleQty(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">العملة المعتمدة:</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-bold text-emerald-600"
              >
                <option value="SAR">SAR (ريال سعودي)</option>
                <option value="YER">YER (ريال يمني)</option>
                <option value="EGP">EGP (جنيه مصري)</option>
                <option value="AED">AED (درهم إماراتي)</option>
                <option value="USD">USD (دولار)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="font-semibold block mb-1">شروط البيع والتسليم:</label>
            <input
              type="text"
              value={terms}
              onChange={(e) => setTerms(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl shadow-lg transition-all text-sm flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>نشر العرض في سوق العالم الذكي</span>
          </button>
        </form>
      </div>
    </div>
  );
};
