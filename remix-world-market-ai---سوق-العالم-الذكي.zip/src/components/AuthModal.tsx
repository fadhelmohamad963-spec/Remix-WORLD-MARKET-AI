import React, { useState } from 'react';
import { X, User, Key, Download, Trash2, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { UserAccount } from '../types/index.ts';

interface AuthModalProps {
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose }) => {
  const { user, login, register, logout, exportUserData, deleteAccount, switchUserRole } = useAuth();
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserAccount['role']>('customer');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (isRegister) {
      const res = await register({ name, email, password, role });
      if (res.success) {
        setSuccessMsg('تم إنشاء الحساب بنجاح وتفعيل المحفظة!');
        setTimeout(() => onClose(), 1000);
      } else {
        setErrorMsg(res.error || 'فشل التسجيل');
      }
    } else {
      const res = await login(email, password);
      if (res.success) {
        setSuccessMsg('تم تسجيل الدخول بنجاح!');
        setTimeout(() => onClose(), 1000);
      } else {
        setErrorMsg(res.error || 'فشل تسجيل الدخول');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-500/10 text-emerald-500 rounded-xl">
              <User className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              {user ? 'إدارة الحساب والجلسة' : isRegister ? 'إنشاء حساب جديد' : 'تسجيل الدخول'}
            </h3>
          </div>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {user ? (
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">الاسم:</span>
                <span className="font-bold">{user.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">البريد:</span>
                <span className="font-mono">{user.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">الدور:</span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-600 font-bold uppercase">
                  {user.role}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">البلد:</span>
                <span>{user.country}</span>
              </div>
            </div>

            {/* Quick Demo Switch */}
            <div>
              <span className="font-bold block mb-1 text-slate-500">تبديل الحساب التجريبي سريعاً:</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => switchUserRole('owner')}
                  className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-emerald-500 hover:text-white rounded-xl font-medium text-[11px] transition-colors"
                >
                  المالك والمطور (Owner)
                </button>
                <button
                  type="button"
                  onClick={() => switchUserRole('supplier')}
                  className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-amber-500 hover:text-white rounded-xl font-medium text-[11px] transition-colors"
                >
                  مورد جملة (Supplier)
                </button>
                <button
                  type="button"
                  onClick={() => switchUserRole('retailer')}
                  className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-sky-500 hover:text-white rounded-xl font-medium text-[11px] transition-colors"
                >
                  تاجر تجزئة (Retailer)
                </button>
                <button
                  type="button"
                  onClick={() => switchUserRole('customer')}
                  className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-emerald-500 hover:text-white rounded-xl font-medium text-[11px] transition-colors"
                >
                  متسوق (Customer)
                </button>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={exportUserData}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تصدير بياناتي (JSON)</span>
              </button>

              <button
                type="button"
                onClick={logout}
                className="px-4 py-2 bg-rose-600 text-white rounded-xl font-bold hover:bg-rose-500"
              >
                تسجيل الخروج
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3 text-xs">
            {errorMsg && <div className="p-2.5 bg-rose-500/10 text-rose-600 rounded-xl">{errorMsg}</div>}
            {successMsg && <div className="p-2.5 bg-emerald-500/10 text-emerald-600 rounded-xl">{successMsg}</div>}

            {isRegister && (
              <div>
                <label className="font-semibold block mb-1">الاسم الكامل:</label>
                <input
                  type="text"
                  required
                  placeholder="محمد أحمد"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
                />
              </div>
            )}

            <div>
              <label className="font-semibold block mb-1">البريد الإلكتروني:</label>
              <input
                type="email"
                required
                placeholder="user@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">كلمة المرور:</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
              />
            </div>

            {isRegister && (
              <div>
                <label className="font-semibold block mb-1">نوع الحساب والصلاحية:</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-medium"
                >
                  <option value="customer">مستهلك / متسوق عادي</option>
                  <option value="retailer">تاجر تجزئة / سوبرماركت</option>
                  <option value="supplier">مورد جملة / مستورد</option>
                </select>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow transition-all text-xs"
            >
              {isRegister ? 'إنشاء الحساب' : 'تسجيل الدخول'}
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setIsRegister(!isRegister)}
                className="text-emerald-600 dark:text-emerald-400 font-semibold hover:underline"
              >
                {isRegister ? 'لديك حساب بالفعل؟ سجّل دخولك' : 'مستخدم جديد؟ أنشئ حساباً الآن'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
