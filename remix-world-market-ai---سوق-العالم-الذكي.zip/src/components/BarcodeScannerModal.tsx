import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Scan,
  Camera,
  Search,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  ShieldCheck,
  PlusCircle,
  Volume2,
} from 'lucide-react';
import { ProductPrice } from '../types/index.ts';
import { useLanguage } from '../contexts/LanguageContext.tsx';

interface BarcodeScannerModalProps {
  onClose: () => void;
  onSelectProduct: (p: ProductPrice) => void;
  onOpenAlert: (p: ProductPrice) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  onClose,
  onSelectProduct,
  onOpenAlert,
}) => {
  const { lang, t } = useLanguage();
  const [barcodeInput, setBarcodeInput] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [scanResult, setScanResult] = useState<any>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Play audio beep on successful detection
  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.15);
    } catch {
      // AudioContext fallback
    }
  };

  // Start Camera
  const startCamera = async () => {
    setErrorMsg('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);

      // Check if browser has native BarcodeDetector API
      if ('BarcodeDetector' in window) {
        const detector = new (window as any).BarcodeDetector({
          formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'qr_code', 'code_128'],
        });
        const interval = setInterval(async () => {
          if (videoRef.current && videoRef.current.readyState === 4) {
            try {
              const barcodes = await detector.detect(videoRef.current);
              if (barcodes.length > 0) {
                const detectedCode = barcodes[0].rawValue;
                clearInterval(interval);
                playBeep();
                stopCamera();
                handleLookup(detectedCode);
              }
            } catch {
              // Frame detect skipped
            }
          }
        }, 300);
      }
    } catch (err: any) {
      console.warn('Camera access denied or unsupported:', err);
      setErrorMsg('تعذر تشغيل الكاميرا في هذه البيئة. يمكنك استخدام الإدخال اليدوي أو النقر على نماذج الباركود أدناه.');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const handleLookup = async (code: string) => {
    const cleanCode = code.trim();
    if (!cleanCode) return;
    setLoading(true);
    setErrorMsg('');
    setScanResult(null);

    try {
      const res = await fetch(`/api/barcode/${encodeURIComponent(cleanCode)}`);
      const data = await res.json();
      setScanResult(data);
      if (!data.success && !data.externalData) {
        setErrorMsg(data.message || 'لم يتم العثور على المنتج في قواعد البيانات.');
      }
    } catch (e: any) {
      setErrorMsg(e.message || 'حدث خطأ أثناء فحص الباركود');
    } finally {
      setLoading(false);
    }
  };

  const sampleBarcodes = [
    { name: 'أرز الشعلان 10 كجم', code: '6281007010214' },
    { name: 'سكر الأسرة 10 كجم', code: '6281015300017' },
    { name: 'زيت ذرة عافية 9 لتر', code: '6281006100121' },
    { name: 'حليب المراعي 12×1 لتر', code: '6281007011112' },
    { name: 'مسحوق إريال 7 كجم', code: '8001090334812' },
    { name: 'شاي ليبتون 100 كيس', code: '8714100770543' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/10 text-emerald-500 rounded-xl">
              <Scan className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                قارئ الباركود الذكي (Barcode Scanner)
              </h2>
              <p className="text-xs text-slate-500">
                مسح رموز EAN-13, UPC-A, QR والربط الفوري بالأسعار وقاعدة البيانات العالمية
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Camera Viewfinder Section */}
          <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 aspect-video max-h-64 flex flex-col items-center justify-center">
            {cameraActive ? (
              <>
                <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline muted />
                {/* Visual reticle & laser */}
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className="w-64 h-36 border-2 border-dashed border-emerald-400 rounded-xl relative">
                    <div className="absolute top-0 inset-x-0 h-0.5 bg-emerald-400 shadow-[0_0_8px_#10b981] animate-bounce"></div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={stopCamera}
                  className="absolute bottom-3 px-3 py-1 bg-red-600/80 hover:bg-red-600 text-white text-xs rounded-full shadow"
                >
                  إيقاف الكاميرا
                </button>
              </>
            ) : (
              <div className="text-center p-6 space-y-3">
                <div className="w-12 h-12 mx-auto rounded-full bg-slate-900 border border-slate-800 text-emerald-400 flex items-center justify-center">
                  <Camera className="w-6 h-6" />
                </div>
                <p className="text-xs text-slate-400 max-w-sm">
                  وجّه الكاميرا نحو باركود أي سلعة غذائية أو سوبرماركت للتعرف الفوري على أسعارها ومقارنتها
                </p>
                <button
                  type="button"
                  onClick={startCamera}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md transition-all inline-flex items-center gap-2"
                >
                  <Camera className="w-4 h-4" />
                  تشغيل كاميرا الهاتف / الحاسوب
                </button>
              </div>
            )}
          </div>

          {errorMsg && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-700 dark:text-amber-400 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-500" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Manual Input Bar */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              أو أدخل رقم الباركود يدويًا (13 أو 12 رقم):
            </label>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleLookup(barcodeInput);
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={barcodeInput}
                onChange={(e) => setBarcodeInput(e.target.value)}
                placeholder="مثال: 6281007010214"
                className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl text-xs sm:text-sm font-mono focus:outline-none focus:border-emerald-500"
              />
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shadow"
              >
                <Search className="w-3.5 h-3.5" />
                <span>{loading ? 'جاري الفحص...' : 'فحص'}</span>
              </button>
            </form>
          </div>

          {/* Quick-Test Sample Chips */}
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              نماذج جاهزة للاختبار الفوري السريع:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {sampleBarcodes.map((item) => (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => {
                    setBarcodeInput(item.code);
                    handleLookup(item.code);
                  }}
                  className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-slate-700 dark:text-slate-300 hover:text-emerald-600 text-xs rounded-lg border border-slate-200 dark:border-slate-700 transition-colors flex items-center gap-1.5 font-mono"
                >
                  <span className="font-sans font-medium">{item.name}</span>
                  <span className="text-[10px] text-slate-400">({item.code.slice(-5)})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Scan Results Card */}
          {scanResult && (
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  نتيجة فحص الباركود: {scanResult.barcode}
                </span>
                <span className="text-[11px] font-mono text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded">
                  {scanResult.source === 'local_verified_db' ? 'قاعدة البيانات الموثقة' : 'سجل OpenFoodFacts العالمي'}
                </span>
              </div>

              {/* Local Matches */}
              {scanResult.matches && scanResult.matches.length > 0 && (
                <div className="space-y-2">
                  {scanResult.matches.map((item: ProductPrice) => (
                    <div
                      key={item.id}
                      className="bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={item.imageUrl}
                          alt=""
                          className="w-14 h-14 object-cover rounded-lg bg-slate-100 dark:bg-slate-800"
                        />
                        <div>
                          <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                            {lang === 'ar' ? item.productNameAr : item.productNameEn}
                          </h4>
                          <p className="text-[11px] text-slate-500">
                            {item.storeOrSupplier} • {item.city} ({item.countryNameAr})
                          </p>
                          <div className="mt-1 flex items-baseline gap-2">
                            <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400">
                              {item.retailPrice.toLocaleString()} {item.currency} (تجزئة)
                            </span>
                            <span className="text-xs font-semibold text-amber-600 dark:text-amber-400">
                              جملة: {item.wholesalePrice.toLocaleString()} {item.currency}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            onSelectProduct(item);
                            onClose();
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-xs"
                        >
                          عرض الأسعار الكاملة
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenAlert(item)}
                          className="px-2.5 py-1.5 bg-slate-200 dark:bg-slate-800 hover:bg-amber-500 hover:text-white text-xs rounded-lg transition-colors"
                        >
                          تتبع السعر
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* External OpenFoodFacts match */}
              {scanResult.externalData && (
                <div className="bg-sky-50 dark:bg-sky-950/20 border border-sky-500/30 rounded-xl p-3 space-y-2">
                  <div className="flex items-center gap-3">
                    {scanResult.externalData.imageUrl && (
                      <img
                        src={scanResult.externalData.imageUrl}
                        alt=""
                        className="w-14 h-14 object-cover rounded-lg bg-white"
                      />
                    )}
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                        {scanResult.externalData.productNameAr}
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        العلامة: {scanResult.externalData.brand} • الحجم: {scanResult.externalData.packageSize}
                      </p>
                      <p className="text-[11px] text-sky-600 dark:text-sky-400 font-medium">
                        المنتج مسجل عالمياً، يمكنك الآن إدخال أسعار التجزئة أو الجملة له في منطقتك.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
