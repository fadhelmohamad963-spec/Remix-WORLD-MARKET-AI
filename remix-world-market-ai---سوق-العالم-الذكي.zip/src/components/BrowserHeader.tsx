import React, { useState } from 'react';
import {
  Globe,
  Search,
  Scan,
  Bot,
  Wallet,
  Sun,
  Moon,
  Bookmark,
  Plus,
  X,
  RotateCw,
  ArrowRight,
  ArrowLeft,
  ChevronDown,
  User,
  ShieldCheck,
  Building2,
  Store,
  Bell,
  Code2,
} from 'lucide-react';
import { useBrowser } from '../contexts/BrowserContext.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import { useTheme } from '../contexts/ThemeContext.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';

interface BrowserHeaderProps {
  onOpenScanner: () => void;
  onOpenAi: () => void;
  onOpenAuth: () => void;
  onOpenAlerts: () => void;
}

export const BrowserHeader: React.FC<BrowserHeaderProps> = ({
  onOpenScanner,
  onOpenAi,
  onOpenAuth,
  onOpenAlerts,
}) => {
  const {
    tabs,
    activeTabId,
    openTab,
    closeTab,
    setActiveTabId,
    browserUrl,
    setBrowserUrl,
    selectedCountry,
    setSelectedCountry,
    selectedCurrency,
    setSelectedCurrency,
    searchQuery,
    setSearchQuery,
    bookmarks,
  } = useBrowser();

  const { lang, setLang, dir, t } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { user, switchUserRole } = useAuth();

  const [showBookmarksMenu, setShowBookmarksMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    openTab({
      title: `بحث: ${searchQuery}`,
      url: `worldmarket://search?q=${encodeURIComponent(searchQuery)}`,
      type: 'search',
      data: { query: searchQuery },
    });
  };

  const countries = [
    { code: 'all', nameAr: '🌐 جميع البلدان', nameEn: '🌐 All Countries' },
    { code: 'SA', nameAr: '🇸🇦 السعودية', nameEn: '🇸🇦 Saudi Arabia' },
    { code: 'YE', nameAr: '🇾🇪 اليمن', nameEn: '🇾🇪 Yemen' },
    { code: 'EG', nameAr: '🇪🇬 مصر', nameEn: '🇪🇬 Egypt' },
    { code: 'AE', nameAr: '🇦🇪 الإمارات', nameEn: '🇦🇪 UAE' },
  ];

  const currencies = ['SAR', 'YER', 'EGP', 'AED', 'USD', 'EUR'];

  return (
    <header className="sticky top-0 z-40 bg-slate-900 text-slate-100 border-b border-slate-800 shadow-md">
      {/* 1. Browser Tab Strip */}
      <div className="flex items-center gap-1 px-2 pt-2 bg-slate-950 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-1.5 px-2 text-xs font-semibold text-emerald-400">
          <Globe className="w-4 h-4 animate-pulse" />
          <span className="hidden sm:inline font-mono tracking-wider">WORLD MARKET</span>
        </div>

        {tabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          return (
            <div
              key={tab.id}
              onClick={() => {
                setActiveTabId(tab.id);
                setBrowserUrl(tab.url);
              }}
              className={`group flex items-center gap-2 px-3 py-1.5 text-xs rounded-t-lg cursor-pointer max-w-[200px] transition-all border-t border-x ${
                isActive
                  ? 'bg-slate-900 border-slate-700 text-white font-medium shadow-sm'
                  : 'bg-slate-950 border-transparent text-slate-400 hover:bg-slate-900/60 hover:text-slate-200'
              }`}
            >
              <span className="truncate">{tab.title}</span>
              {tabs.length > 1 && (
                <button
                  type="button"
                  onClick={(e) => closeTab(tab.id, e)}
                  className="opacity-0 group-hover:opacity-100 hover:bg-slate-800 p-0.5 rounded text-slate-400 hover:text-red-400 transition-opacity"
                  title="إغلاق التبويب"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          );
        })}

        <button
          type="button"
          onClick={() =>
            openTab({
              title: lang === 'ar' ? 'تبويب جديد' : 'New Tab',
              url: 'worldmarket://home',
              type: 'home',
            })
          }
          className="p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-slate-900 rounded-md transition-colors"
          title="فتح تبويب جديد"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 2. Browser Navigation & Omni-Search Bar */}
      <div className="px-3 py-2 flex flex-wrap items-center gap-2">
        {/* Nav Controls */}
        <div className="flex items-center gap-1 text-slate-400">
          <button
            type="button"
            onClick={() => window.history.back()}
            className="p-1.5 rounded hover:bg-slate-800 hover:text-white transition-colors"
            title="السابق"
          >
            {dir === 'rtl' ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="p-1.5 rounded hover:bg-slate-800 hover:text-white transition-colors"
            title="تحديث"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowBookmarksMenu(!showBookmarksMenu)}
              className="p-1.5 rounded hover:bg-slate-800 hover:text-amber-400 text-slate-400 transition-colors"
              title="المفضلة"
            >
              <Bookmark className="w-4 h-4" />
            </button>
            {showBookmarksMenu && (
              <div className="absolute top-full mt-1 start-0 w-56 bg-slate-800 border border-slate-700 rounded-lg shadow-xl py-2 z-50">
                <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 border-b border-slate-700 mb-1">
                  المفضلة وسجل التصفح
                </div>
                {bookmarks.map((bm, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      openTab({ title: bm.title, url: bm.url, type: bm.type });
                      setShowBookmarksMenu(false);
                    }}
                    className="w-full text-start px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-700 flex items-center justify-between"
                  >
                    <span className="truncate">{bm.title}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* The Omni-Search Bar */}
        <form
          onSubmit={handleSearchSubmit}
          className="flex-1 min-w-[280px] flex items-center bg-slate-950/90 border border-slate-700 rounded-full px-3 py-1.5 focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500 transition-all shadow-inner"
        >
          <Search className="w-4 h-4 text-emerald-400 shrink-0 me-2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full bg-transparent text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none"
          />

          {/* Quick Country Selector in Omni-bar */}
          <div className="flex items-center gap-1 ms-2 border-s border-slate-700 ps-2">
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="bg-transparent text-[11px] text-slate-300 focus:outline-none cursor-pointer hover:text-white"
            >
              {countries.map((c) => (
                <option key={c.code} value={c.code} className="bg-slate-900 text-slate-200">
                  {lang === 'ar' ? c.nameAr : c.nameEn}
                </option>
              ))}
            </select>
          </div>

          {/* Currency selector */}
          <div className="hidden sm:flex items-center gap-1 ms-2 border-s border-slate-700 ps-2">
            <select
              value={selectedCurrency}
              onChange={(e) => setSelectedCurrency(e.target.value)}
              className="bg-transparent text-[11px] text-emerald-400 font-semibold focus:outline-none cursor-pointer"
            >
              {currencies.map((curr) => (
                <option key={curr} value={curr} className="bg-slate-900 text-slate-200">
                  {curr}
                </option>
              ))}
            </select>
          </div>
        </form>

        {/* Primary Action Buttons */}
        <div className="flex items-center gap-1.5">
          {/* Barcode scanner button */}
          <button
            type="button"
            onClick={onOpenScanner}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-medium rounded-lg border border-slate-700 transition-colors"
            title={t.scanBarcode}
          >
            <Scan className="w-4 h-4 text-emerald-400" />
            <span className="hidden md:inline">{t.scanBarcode}</span>
          </button>

          {/* AI Assistant button */}
          <button
            type="button"
            onClick={onOpenAi}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
            title={t.aiAssistant}
          >
            <Bot className="w-4 h-4 animate-bounce" />
            <span className="hidden lg:inline">{t.aiAssistant}</span>
          </button>

          {/* World Wallet Quick Button */}
          <button
            type="button"
            onClick={() =>
              openTab({
                title: 'WORLD WALLET',
                url: 'worldmarket://wallet',
                type: 'wallet',
              })
            }
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 transition-colors"
            title="محفظة WORLD WALLET"
          >
            <Wallet className="w-4 h-4 text-amber-400" />
            <span className="text-[11px] text-amber-300 font-mono font-medium">
              {user?.walletBalance?.SAR ? `${user.walletBalance.SAR.toLocaleString()} SAR` : '0 SAR'}
            </span>
          </button>

          {/* Price Alerts */}
          <button
            type="button"
            onClick={onOpenAlerts}
            className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-colors relative"
            title="تنبيهات الأسعار"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 end-1 w-2 h-2 bg-emerald-500 rounded-full"></span>
          </button>

          {/* Language Switch */}
          <button
            type="button"
            onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            className="px-2 py-1 text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
          >
            {lang === 'ar' ? 'EN' : 'عربي'}
          </button>

          {/* Dark / Light Toggle */}
          <button
            type="button"
            onClick={toggleTheme}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title="تبديل المظهر"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* User Account / Role Switcher */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-1.5 px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 text-xs transition-colors"
            >
              <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px]">
                {user ? user.name[0] : 'U'}
              </div>
              <span className="hidden xl:inline text-[11px] text-slate-200 truncate max-w-[90px]">
                {user ? user.name : t.login}
              </span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showUserMenu && (
              <div className="absolute top-full mt-1 end-0 w-64 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl py-2 z-50">
                <div className="px-3 py-2 border-b border-slate-700">
                  <p className="text-xs font-semibold text-white truncate">{user?.name}</p>
                  <p className="text-[11px] text-slate-400 truncate">{user?.email}</p>
                  <span className="inline-block mt-1 px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-500/20 text-emerald-300">
                    الدور: {user?.role.toUpperCase()}
                  </span>
                </div>

                <div className="py-1">
                  <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    تبديل دور المستخدم (محاكاة الصلاحيات)
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      switchUserRole('owner');
                      setShowUserMenu(false);
                    }}
                    className={`w-full text-start px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-slate-700 ${
                      user?.role === 'owner' ? 'text-emerald-400 font-bold' : 'text-slate-300'
                    }`}
                  >
                    <Code2 className="w-3.5 h-3.5 text-indigo-400" />
                    المالك والمطور (Owner / AI Developer)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      switchUserRole('supplier');
                      setShowUserMenu(false);
                    }}
                    className={`w-full text-start px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-slate-700 ${
                      user?.role === 'supplier' ? 'text-emerald-400 font-bold' : 'text-slate-300'
                    }`}
                  >
                    <Building2 className="w-3.5 h-3.5 text-amber-400" />
                    مورد جملة معتمد (Wholesale Supplier)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      switchUserRole('retailer');
                      setShowUserMenu(false);
                    }}
                    className={`w-full text-start px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-slate-700 ${
                      user?.role === 'retailer' ? 'text-emerald-400 font-bold' : 'text-slate-300'
                    }`}
                  >
                    <Store className="w-3.5 h-3.5 text-sky-400" />
                    تاجر تجزئة / سوبرماركت (Retailer)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      switchUserRole('customer');
                      setShowUserMenu(false);
                    }}
                    className={`w-full text-start px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-slate-700 ${
                      user?.role === 'customer' ? 'text-emerald-400 font-bold' : 'text-slate-300'
                    }`}
                  >
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    مستهلك / متسوق (Customer)
                  </button>
                </div>

                <div className="border-t border-slate-700 pt-1 mt-1">
                  <button
                    type="button"
                    onClick={() => {
                      onOpenAuth();
                      setShowUserMenu(false);
                    }}
                    className="w-full text-start px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-700 flex items-center gap-2"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    إدارة الحساب والأمان
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
