import React, { useState, useEffect } from 'react';
import { X, Scale, ShieldCheck, ExternalLink, ArrowRightLeft, Info, Truck } from 'lucide-react';
import { ProductPrice } from '../types/index.ts';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import { useBrowser } from '../contexts/BrowserContext.tsx';

interface PriceComparisonModalProps {
  product: ProductPrice | null;
  onClose: () => void;
}

export const PriceComparisonModal: React.FC<PriceComparisonModalProps> = ({ product, onClose }) => {
  const { lang, t } = useLanguage();
  const { selectedCurrency } = useBrowser();
  const [comparisonList, setComparisonList] = useState<ProductPrice[]>([]);
  const [rates, setRates] = useState<Record<string, number>>({});
  const [targetCurrency, setTargetCurrency] = useState<string>('SAR');
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    if (!product) return;
    setLoading(true);

    // Fetch comparison items and exchange rates
    fetch(`/api/compare?q=${encodeURIComponent(product.category)}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          // Put current product first, plus items in same category or matching query
          const filtered = data.items.filter((item: ProductPrice) => item.category === product.category);
          setComparisonList(filtered.length > 0 ? filtered : [product]);
          setRates(data.exchangeRates || {});
        }
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, [product]);

  if (!product) return null;

  // Currency Converter helper
  const convertPrice = (price: number, fromCurrency: string, toCurr: string) => {
    if (fromCurrency === toCurr) return price;
    const fromRate = rates[fromCurrency] || 1;
    const toRate = rates[toCurr] || 1;
    // Price in USD = price / fromRate
    const priceInUSD = price / fromRate;
    return priceInUSD * toRate;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950/80">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-500/10 text-emerald-500 rounded-lg">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                مقارنة الأسعار العالمية الموحدة (Global Price Matrix)
              </h2>
              <p className="text-xs text-slate-500">
                مقارنة حقيقية مبنية على أسعار الصرف الحية والأسعار الموثقة
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Currency Normalizer Bar */}
        <div className="px-4 py-3 bg-slate-100 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-emerald-500" />
            <span className="font-semibold text-slate-700 dark:text-slate-200">
              توحيد عملة المقارنة للعرض:
            </span>
            <div className="flex gap-1">
              {['SAR', 'USD', 'YER', 'EGP', 'AED'].map((curr) => (
                <button
                  key={curr}
                  type="button"
                  onClick={() => setTargetCurrency(curr)}
                  className={`px-2.5 py-1 rounded-md font-bold text-[11px] transition-colors ${
                    targetCurrency === curr
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {curr}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 text-[11px]">
            <Info className="w-3.5 h-3.5 text-sky-400" />
            <span>سعر الصرف: 1 USD = 3.75 SAR = 48.95 EGP = 535 YER</span>
          </div>
        </div>

        {/* Matrix Table */}
        <div className="flex-1 overflow-y-auto p-4">
          <table className="w-full text-start text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-950/50">
                <th className="py-2.5 px-3 text-start font-semibold">المنتج والبلد</th>
                <th className="py-2.5 px-3 text-start font-semibold">المتجر / المورد</th>
                <th className="py-2.5 px-3 text-start font-semibold">السعر الأصلي</th>
                <th className="py-2.5 px-3 text-start font-semibold text-emerald-600 dark:text-emerald-400">
                  السعر بالـ ({targetCurrency})
                </th>
                <th className="py-2.5 px-3 text-start font-semibold">سعر الجملة</th>
                <th className="py-2.5 px-3 text-start font-semibold">الشحن</th>
                <th className="py-2.5 px-3 text-start font-semibold">التحقق</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {comparisonList.map((item) => {
                const convertedRetail = convertPrice(item.retailPrice, item.currency, targetCurrency);
                const convertedWholesale = convertPrice(item.wholesalePrice, item.currency, targetCurrency);
                const isSelected = item.id === product.id;

                return (
                  <tr
                    key={item.id}
                    className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${
                      isSelected ? 'bg-emerald-500/5 dark:bg-emerald-500/10 font-medium' : ''
                    }`}
                  >
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <img
                          src={item.imageUrl}
                          alt=""
                          className="w-10 h-10 rounded object-cover shrink-0 bg-slate-100 dark:bg-slate-800"
                        />
                        <div>
                          <p className="font-bold text-slate-900 dark:text-slate-100 leading-snug">
                            {lang === 'ar' ? item.productNameAr : item.productNameEn}
                          </p>
                          <span className="text-[11px] text-slate-500">
                            {item.countryNameAr} • {item.packageSize}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {item.storeOrSupplier}
                      </span>
                      <p className="text-[10px] text-slate-400">{item.city}</p>
                    </td>

                    <td className="py-3 px-3">
                      <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                        {item.retailPrice.toLocaleString()} {item.currency}
                      </span>
                    </td>

                    <td className="py-3 px-3">
                      <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
                        {convertedRetail.toFixed(2)} {targetCurrency}
                      </span>
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-mono text-amber-600 dark:text-amber-400">
                        {convertedWholesale.toFixed(2)} {targetCurrency}
                      </div>
                      <span className="text-[10px] text-slate-400 block">
                        أقل كمية: {item.minWholesaleQty}
                      </span>
                    </td>

                    <td className="py-3 px-3 text-slate-500">
                      {item.shippingCost && item.shippingCost > 0 ? (
                        <span className="flex items-center gap-1 text-[11px]">
                          <Truck className="w-3 h-3 text-sky-500" />
                          {item.shippingCost} {item.currency}
                        </span>
                      ) : (
                        <span className="text-emerald-600 font-bold text-[11px]">شحن مجاني/استلام</span>
                      )}
                    </td>

                    <td className="py-3 px-3">
                      {item.verified ? (
                        <span className="inline-flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
                          <ShieldCheck className="w-3.5 h-3.5" />
                          موثق
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-400">قيد المراجعة</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Compliance note */}
          <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 rounded-xl text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
            <p>
              تنبيه الشفافية: الأسعار المعروضة أعلاه مستمدة من القوائم الرسمية للمتاجر والموردين المسجلين. قد تختلف الأسعار عند حساب الضرائب المحلية وتكاليف التوصيل للمنازل. لا نطلق وصف "الأرخص عالمياً" إلا بموجب تحقق رقمي كامل من شحنة المورد وأسعار الصرف الحية.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
