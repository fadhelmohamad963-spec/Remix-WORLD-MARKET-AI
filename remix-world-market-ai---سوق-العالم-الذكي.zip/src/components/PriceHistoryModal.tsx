import React from 'react';
import { X, LineChart, TrendingDown, TrendingUp, Calendar, Store } from 'lucide-react';
import { ProductPrice } from '../types/index.ts';
import { useLanguage } from '../contexts/LanguageContext.tsx';

interface PriceHistoryModalProps {
  product: ProductPrice | null;
  onClose: () => void;
}

export const PriceHistoryModal: React.FC<PriceHistoryModalProps> = ({ product, onClose }) => {
  const { lang } = useLanguage();
  if (!product) return null;

  const history = product.history || [];
  const prices = history.map((h) => h.retailPrice);
  const minPrice = Math.min(...prices, product.retailPrice);
  const maxPrice = Math.max(...prices, product.retailPrice);
  const priceRange = maxPrice - minPrice || 1;

  // Chart coordinates calculation (SVG width 500, height 200)
  const width = 500;
  const height = 180;
  const padding = 35;

  const getCoordinates = (index: number, price: number) => {
    const x = padding + (index / (history.length - 1 || 1)) * (width - 2 * padding);
    const y = height - padding - ((price - minPrice) / priceRange) * (height - 2 * padding);
    return { x, y };
  };

  const retailPoints = history.map((h, i) => getCoordinates(i, h.retailPrice));
  const wholesalePoints = history.map((h, i) => getCoordinates(i, h.wholesalePrice));

  const retailSvgPath = retailPoints.reduce(
    (acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`,
    ''
  );

  const wholesaleSvgPath = wholesalePoints.reduce(
    (acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`,
    ''
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950/80">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-500/10 text-emerald-500 rounded-xl">
              <LineChart className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                السجل التاريخي وتطور الأسعار
              </h3>
              <p className="text-xs text-slate-500 truncate max-w-sm">
                {lang === 'ar' ? product.productNameAr : product.productNameEn}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Key Metrics */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 block">السعر الحالي (تجزئة)</span>
              <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
                {product.retailPrice} {product.currency}
              </span>
            </div>
            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 block">أعلى سعر مسجل</span>
              <span className="text-sm font-extrabold text-rose-500 font-mono">
                {maxPrice} {product.currency}
              </span>
            </div>
            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 block">أدنى سعر مسجل</span>
              <span className="text-sm font-extrabold text-emerald-500 font-mono">
                {minPrice} {product.currency}
              </span>
            </div>
          </div>

          {/* SVG Price Chart */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 relative">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                  سعر التجزئة
                </span>
                <span className="flex items-center gap-1 text-amber-400 font-semibold">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                  سعر الجملة
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-500">30 يوماً</span>
            </div>

            <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-44 overflow-visible">
              {/* Grid Lines */}
              <line x1={padding} y1={padding} x2={width - padding} y2={padding} stroke="#334155" strokeDasharray="3 3" opacity="0.4" />
              <line x1={padding} y1={height / 2} x2={width - padding} y2={height / 2} stroke="#334155" strokeDasharray="3 3" opacity="0.4" />
              <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#334155" opacity="0.6" />

              {/* Retail Line */}
              <path d={retailSvgPath} fill="none" stroke="#10b981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
              {/* Wholesale Line */}
              <path d={wholesaleSvgPath} fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeDasharray="4 4" strokeLinecap="round" strokeLinejoin="round" />

              {/* Data points */}
              {retailPoints.map((pt, i) => (
                <g key={`r-${i}`}>
                  <circle cx={pt.x} cy={pt.y} r="4.5" fill="#10b981" stroke="#020617" strokeWidth="2" />
                  <text x={pt.x} y={pt.y - 8} fill="#94a3b8" fontSize="10" textAnchor="middle" fontFamily="monospace">
                    {history[i].retailPrice}
                  </text>
                  <text x={pt.x} y={height - 12} fill="#64748b" fontSize="9" textAnchor="middle">
                    {history[i].date.slice(5)}
                  </text>
                </g>
              ))}
            </svg>
          </div>

          <div className="text-[11px] text-slate-500 flex items-center justify-between">
            <span className="flex items-center gap-1">
              <Store className="w-3.5 h-3.5 text-slate-400" />
              المتجر: {product.storeOrSupplier} ({product.city})
            </span>
            <span>آخر تدقيق: {product.lastUpdated.slice(0, 10)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
