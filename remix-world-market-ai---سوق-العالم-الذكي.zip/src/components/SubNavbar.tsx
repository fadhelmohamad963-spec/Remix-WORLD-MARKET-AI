import React from 'react';
import {
  Search,
  Scale,
  Scan,
  Boxes,
  TrendingDown,
  Wallet,
  Terminal,
  Shield,
  Layers,
} from 'lucide-react';
import { useBrowser } from '../contexts/BrowserContext.tsx';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';

export const SubNavbar: React.FC = () => {
  const { activeTab, openTab } = useBrowser();
  const { t } = useLanguage();
  const { user } = useAuth();

  const navItems = [
    {
      type: 'home' as const,
      title: t.appName,
      url: 'worldmarket://home',
      icon: Layers,
      labelAr: 'الرئيسية والسلع',
      labelEn: 'Home & Staples',
    },
    {
      type: 'search' as const,
      title: 'محرك البحث الشامل',
      url: 'worldmarket://search',
      icon: Search,
      labelAr: 'البحث المتقدم',
      labelEn: 'Advanced Search',
    },
    {
      type: 'compare' as const,
      title: 'مقارنة الأسعار العالمية',
      url: 'worldmarket://compare',
      icon: Scale,
      labelAr: 'المقارنة العالمية',
      labelEn: 'Global Compare',
    },
    {
      type: 'wholesale' as const,
      title: 'عروض الجملة والموردين',
      url: 'worldmarket://wholesale',
      icon: Boxes,
      labelAr: 'بوابة الجملة والتوريد',
      labelEn: 'Wholesale & B2B',
    },
    {
      type: 'alerts' as const,
      title: 'متابعة الأسعار والتنبيهات',
      url: 'worldmarket://alerts',
      icon: TrendingDown,
      labelAr: 'متابعة الأسعار',
      labelEn: 'Price Tracker',
    },
    {
      type: 'wallet' as const,
      title: 'WORLD WALLET',
      url: 'worldmarket://wallet',
      icon: Wallet,
      labelAr: 'المحفظة المالية',
      labelEn: 'World Wallet',
    },
    {
      type: 'dev' as const,
      title: 'مكتب المطور الذكي',
      url: 'worldmarket://dev',
      icon: Terminal,
      labelAr: 'مكتب المطور AI',
      labelEn: 'AI Dev Office',
      restricted: true,
      badge: 'PRO',
    },
    {
      type: 'admin' as const,
      title: 'لوحة الإدارة',
      url: 'worldmarket://admin',
      icon: Shield,
      labelAr: 'لوحة الإدارة',
      labelEn: 'Admin Panel',
      restricted: true,
    },
  ];

  return (
    <nav className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-3 py-1.5 overflow-x-auto no-scrollbar shadow-xs">
      <div className="flex items-center gap-1 min-w-max">
        {navItems.map((item) => {
          const isActive = activeTab.type === item.type;
          const Icon = item.icon;
          return (
            <button
              key={item.type}
              type="button"
              onClick={() =>
                openTab({
                  title: item.title,
                  url: item.url,
                  type: item.type,
                })
              }
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800 font-semibold shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
              <span>{item.labelAr}</span>
              {item.badge && (
                <span className="px-1.5 py-0.2 bg-indigo-500/10 text-indigo-500 dark:text-indigo-400 text-[10px] font-mono rounded font-bold">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
