import React, { useState, useEffect } from 'react';
import { Shield, Users, Database, AlertTriangle, CheckCircle2, Lock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { MisleadingPriceReport, UserAccount } from '../types/index.ts';

export const AdminPanel: React.FC = () => {
  const { user, usersList } = useAuth();
  const [reports, setReports] = useState<MisleadingPriceReport[]>([]);
  const [loading, setLoading] = useState(true);

  const isAuthorized = user?.role === 'owner' || user?.role === 'admin';

  const fetchReports = async () => {
    try {
      const res = await fetch('/api/reports');
      const data = await res.json();
      if (data.success) setReports(data.reports);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  if (!isAuthorized) {
    return (
      <div className="p-8 max-w-xl mx-auto my-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl text-center space-y-4">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          منطقة مقيدة - لوحة الإدارة العامة
        </h2>
        <p className="text-xs text-slate-500">
          هذا القسم يتطلب صلاحيات إدارية (Admin أو Owner) لإدارة المستخدمين ومراجعة البلاغات.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
          <Shield className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-base font-bold">لوحة الإدارة المركزية (System Administration)</h2>
          <p className="text-xs text-slate-400">
            إدارة الحسابات والصلاحيات، فحص بلاغات الأسعار المضللة، ومراقبة جودة البيانات
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Users & Roles Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
            <Users className="w-4 h-4 text-emerald-500" />
            حسابات المستخدمين وتوزيع الصلاحيات ({usersList.length})
          </h3>

          <div className="space-y-2 max-h-80 overflow-y-auto">
            {usersList.map((u) => (
              <div
                key={u.id}
                className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <p className="font-bold text-slate-900 dark:text-slate-100">{u.name}</p>
                  <p className="text-[11px] text-slate-400 font-mono">{u.email}</p>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 uppercase">
                  {u.role}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Misleading Price Reports */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            بلاغات الأسعار غير الدقيقة والمضللة ({reports.length})
          </h3>

          {reports.length === 0 ? (
            <div className="text-center py-12 text-xs text-slate-400">
              لا توجد بلاغات غير محلولة حالياً. جميع الأسعار مطابقة لمصادرها الرسمية.
            </div>
          ) : (
            <div className="space-y-2">
              {reports.map((r) => (
                <div
                  key={r.id}
                  className="p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-300 dark:border-amber-800/50 rounded-xl text-xs space-y-1"
                >
                  <div className="flex justify-between font-bold">
                    <span>{r.productName}</span>
                    <span className="text-amber-600">{r.status}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 text-[11px]">{r.reason}</p>
                  <p className="text-[10px] text-slate-400">
                    السعر المبلغ عنه: {r.reportedPrice} • السعر الفعلي المزعوم: {r.claimedActualPrice}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
