import React, { useState, useEffect } from 'react';
import { Bell, Trash2, Plus, X, CheckCircle2, TrendingDown } from 'lucide-react';
import { PriceAlert, ProductPrice } from '../types/index.ts';
import { useAuth } from '../contexts/AuthContext.tsx';

interface PriceAlertsModalProps {
  initialProduct?: ProductPrice | null;
  onClose: () => void;
}

export const PriceAlertsModal: React.FC<PriceAlertsModalProps> = ({ initialProduct, onClose }) => {
  const { user } = useAuth();
  const [alerts, setAlerts] = useState<PriceAlert[]>([]);
  const [loading, setLoading] = useState(true);

  const [productId, setProductId] = useState(initialProduct ? initialProduct.productId : 'rice-alshalan-10kg');
  const [productName, setProductName] = useState(initialProduct ? initialProduct.productNameAr : 'أرز سيلا بسمتي الشعلان 10 كجم');
  const [targetPrice, setTargetPrice] = useState(initialProduct ? String(Math.floor(initialProduct.retailPrice * 0.95)) : '75');
  const [currency, setCurrency] = useState<string>(initialProduct ? initialProduct.currency : 'SAR');

  const fetchAlerts = async () => {
    try {
      const res = await fetch(`/api/alerts?userId=${user?.id || 'user-customer-demo'}`);
      const data = await res.json();
      if (data.success) {
        setAlerts(data.alerts);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, [user]);

  const handleCreateAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id || 'user-customer-demo',
          productId,
          productName,
          targetPrice: Number(targetPrice),
          currency,
          direction: 'below',
        }),
      });
      const data = await res.json();
      if (data.success) {
        await fetchAlerts();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/alerts/${id}?userId=${user?.id || 'user-customer-demo'}`, {
        method: 'DELETE',
      });
      await fetchAlerts();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg p-6 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-500/10 text-amber-500 rounded-xl">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                متابعة الأسعار والتنبيهات الذكية (Price Alerts)
              </h3>
              <p className="text-xs text-slate-500">
                تلقّ إشعاراً فورياً عند وصول سعر السلعة إلى السعر المستهدف
              </p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Add Alert Form */}
        <form onSubmit={handleCreateAlert} className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 text-xs">
          <div>
            <label className="font-semibold block mb-1">السلعة المراد تتبع سعرها:</label>
            <input
              type="text"
              required
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="font-semibold block mb-1">السعر المستهدف (أقل من):</label>
              <input
                type="number"
                required
                value={targetPrice}
                onChange={(e) => setTargetPrice(e.target.value)}
                className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl font-mono"
              />
            </div>
            <div>
              <label className="font-semibold block mb-1">العملة:</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl font-bold"
              >
                <option value="SAR">SAR (ريال سعودي)</option>
                <option value="YER">YER (ريال يمني)</option>
                <option value="EGP">EGP (جنيه مصري)</option>
                <option value="AED">AED (درهم إماراتي)</option>
                <option value="USD">USD (دولار)</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow transition-all flex items-center justify-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>تثبيت تنبيه جديد</span>
          </button>
        </form>

        {/* Active Alerts List */}
        <div className="space-y-2">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
            التنبيهات النشطة المسجلة:
          </span>

          {alerts.length === 0 ? (
            <p className="text-xs text-slate-400 py-3 text-center">لا توجد تنبيهات حالياً.</p>
          ) : (
            alerts.map((alt) => (
              <div
                key={alt.id}
                className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <p className="font-bold text-slate-900 dark:text-slate-100">{alt.productName}</p>
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-mono">
                    تنبيه عندما ينخفض إلى ≤ {alt.targetPrice} {alt.currency}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleDelete(alt.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  title="حذف التنبيه"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
