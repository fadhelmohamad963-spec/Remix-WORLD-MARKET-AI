import React, { useState, useEffect } from 'react';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  PlusCircle,
  ShieldCheck,
  AlertCircle,
  FileText,
  X,
  CheckCircle2,
  Lock,
  Building2,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { WalletTransaction } from '../types/index.ts';

export const WorldWallet: React.FC = () => {
  const { user } = useAuth();
  const [balances, setBalances] = useState<Record<string, number>>({});
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [showTransferModal, setShowTransferModal] = useState<boolean>(false);
  const [showReceiptModal, setShowReceiptModal] = useState<WalletTransaction | null>(null);

  // Transfer form
  const [recipientEmail, setRecipientEmail] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('SAR');
  const [note, setNote] = useState('');
  const [transferError, setTransferError] = useState('');
  const [transferSuccess, setTransferSuccess] = useState(false);

  const fetchWallet = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/wallet/${user.id}`);
      const data = await res.json();
      if (data.success && data.wallet) {
        setBalances(data.wallet.balances || {});
        setTransactions(data.wallet.transactions || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWallet();
  }, [user]);

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setTransferError('');
    setTransferSuccess(false);

    try {
      const res = await fetch('/api/wallet/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: user.id,
          recipientEmail,
          amount: Number(amount),
          currency,
          note,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setTransferSuccess(true);
        setShowReceiptModal(data.transaction);
        setShowTransferModal(false);
        setRecipientEmail('');
        setAmount('');
        setNote('');
        await fetchWallet();
      } else {
        setTransferError(data.error || 'فشل التحويل');
      }
    } catch (err: any) {
      setTransferError(err.message || 'خطأ في الاتصال بالخادم');
    }
  };

  const handleTopUp = async () => {
    if (!user) return;
    try {
      await fetch('/api/wallet/topup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          currency: 'SAR',
          amount: 5000,
        }),
      });
      await fetchWallet();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Simulation Banner Notice */}
      <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800/80 rounded-2xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-900 dark:text-amber-200 leading-relaxed">
          <strong>إشعار الشفافية المالية:</strong> هذه محفظة رقمية تجريبية (WORLD WALLET Simulation).
          الأرصدة المعروضة هي أرصدة محاكاة مخصصة لاختبار عمليات الشراء، وحجز شحنات الجملة، وإصدار الإيصالات الرقمية قبل ربط بوابات الدفع البنكية الرسمية في البلدان المعتمدة.
        </div>
      </div>

      {/* Main Balances Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Wallet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold tracking-tight">WORLD WALLET</h2>
                <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 font-mono text-[10px] rounded-full font-bold">
                  DEMO ENVIRONMENT
                </span>
              </div>
              <p className="text-xs text-slate-400">
                الحساب الرقمي لـ: {user?.name} ({user?.email})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleTopUp}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl border border-slate-700 transition-colors flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4 text-emerald-400" />
              <span>إيداع رصيد تجريبي (+5000 SAR)</span>
            </button>
            <button
              type="button"
              onClick={() => setShowTransferModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow transition-all flex items-center gap-1.5"
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>تحويل أموال تجريبية</span>
            </button>
          </div>
        </div>

        {/* Multi-currency Balances Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { curr: 'SAR', name: 'ريال سعودي', amount: balances['SAR'] || 0, color: 'text-emerald-400' },
            { curr: 'USD', name: 'دولار أمريكي', amount: balances['USD'] || 0, color: 'text-sky-400' },
            { curr: 'YER', name: 'ريال يمني', amount: balances['YER'] || 0, color: 'text-amber-400' },
            { curr: 'EGP', name: 'جنيه مصري', amount: balances['EGP'] || 0, color: 'text-teal-400' },
          ].map((c) => (
            <div
              key={c.curr}
              className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 backdrop-blur-xs space-y-1"
            >
              <span className="text-[11px] text-slate-400 block">{c.name}</span>
              <div className="text-xl font-extrabold font-mono tracking-tight text-white">
                {c.amount.toLocaleString()}
              </div>
              <span className={`text-[10px] font-bold ${c.color}`}>{c.curr}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Transaction History Ledger */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              سجل التحويلات والعمليات الرقمية (Transaction Ledger)
            </h3>
            <p className="text-xs text-slate-500">
              سجل كامل للتحويلات الصادرة والواردة ورسوم التحويل وحالة التدقيق
            </p>
          </div>
          <button
            type="button"
            onClick={fetchWallet}
            className="p-1.5 text-slate-400 hover:text-emerald-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {transactions.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-400">
            لا توجد معاملات مسجلة حتى الآن في هذه المحفظة.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="py-3 flex flex-wrap items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      tx.type === 'transfer_out'
                        ? 'bg-rose-500/10 text-rose-500'
                        : 'bg-emerald-500/10 text-emerald-500'
                    }`}
                  >
                    {tx.type === 'transfer_out' ? (
                      <ArrowUpRight className="w-5 h-5" />
                    ) : (
                      <ArrowDownLeft className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 dark:text-slate-100">
                      {tx.type === 'transfer_out'
                        ? `تحويل إلى: ${tx.recipientName || tx.recipientEmail}`
                        : 'إيداع رصيد تجريبي'}
                    </p>
                    <p className="text-[11px] text-slate-400 truncate max-w-sm">
                      {tx.referenceNote}
                    </p>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {tx.timestamp.slice(0, 10)} {tx.timestamp.slice(11, 16)} • معرف: {tx.id}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-end">
                  <div>
                    <span
                      className={`text-sm font-extrabold font-mono block ${
                        tx.type === 'transfer_out' ? 'text-rose-600' : 'text-emerald-600'
                      }`}
                    >
                      {tx.type === 'transfer_out' ? '-' : '+'}
                      {tx.amount.toLocaleString()} {tx.currency}
                    </span>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center justify-end gap-0.5">
                      <CheckCircle2 className="w-3 h-3" />
                      {tx.status.toUpperCase()}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowReceiptModal(tx)}
                    className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                    title="عرض الإيصال الرقمي"
                  >
                    <FileText className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Transfer Modal */}
      {showTransferModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <ArrowUpRight className="w-4 h-4 text-emerald-500" />
                تحويل رصيد تجريبي (Simulation Transfer)
              </h3>
              <button
                type="button"
                onClick={() => setShowTransferModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {transferError && (
              <div className="p-3 bg-rose-500/10 text-rose-600 text-xs rounded-xl">
                {transferError}
              </div>
            )}

            <form onSubmit={handleTransfer} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold block mb-1">البريد الإلكتروني للمستلم:</label>
                <input
                  type="email"
                  required
                  placeholder="supplier@albaraka.com أو أي بريد"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold block mb-1">المبلغ:</label>
                  <input
                    type="number"
                    required
                    min="1"
                    placeholder="100"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold block mb-1">العملة:</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl font-bold text-emerald-600"
                  >
                    <option value="SAR">SAR (ريال سعودي)</option>
                    <option value="USD">USD (دولار أمريكي)</option>
                    <option value="YER">YER (ريال يمني)</option>
                    <option value="EGP">EGP (جنيه مصري)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold block mb-1">ملاحظة أو مرجع العملية:</label>
                <input
                  type="text"
                  placeholder="عربون حجز شحنة سكر وأرز"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl"
                />
              </div>

              <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-between text-slate-500">
                <span>رسوم التحويل الرقمي:</span>
                <span className="font-bold text-emerald-600">0.00 {currency} (مجاني)</span>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md transition-all text-xs"
              >
                تأكيد التحويل وإصدار الإيصال
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Digital Receipt Modal */}
      {showReceiptModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-sm p-6 shadow-2xl text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                إيصال تحويل رقمي موثق
              </h3>
              <p className="text-xs text-slate-500">WORLD WALLET Verified Receipt</p>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-start space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">رقم الإيصال:</span>
                <span className="font-mono font-bold">{showReceiptModal.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">المبلغ:</span>
                <span className="font-mono font-extrabold text-emerald-600">
                  {showReceiptModal.amount.toLocaleString()} {showReceiptModal.currency}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">المستلم:</span>
                <span className="font-medium truncate max-w-[160px]">
                  {showReceiptModal.recipientName || showReceiptModal.recipientEmail}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">التاريخ:</span>
                <span className="font-mono">{showReceiptModal.timestamp.slice(0, 16)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">الحالة:</span>
                <span className="text-emerald-500 font-bold">مكتمل وموثق في السجل</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowReceiptModal(null)}
              className="w-full py-2 bg-slate-900 dark:bg-slate-800 text-white rounded-xl text-xs font-bold"
            >
              إغلاق الإيصال
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
