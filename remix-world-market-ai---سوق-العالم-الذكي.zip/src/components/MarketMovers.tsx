import React from 'react';
import { TrendingDown, TrendingUp, Sparkles, CheckCircle2 } from 'lucide-react';
import { ProductPrice } from '../types/index.ts';
import { useLanguage } from '../contexts/LanguageContext.tsx';
import { useBrowser } from '../contexts/BrowserContext.tsx';

interface MarketMoversProps {
  priceDrops: ProductPrice[];
  priceHikes: ProductPrice[];
  onSelectProduct: (p: ProductPrice) => void;
  onOpenCompare: (p: ProductPrice) => void;
}

export const MarketMovers: React.FC<MarketMoversProps> = ({
  priceDrops,
  priceHikes,
  onSelectProduct,
  onOpenCompare,
}) => {
  const { lang } = useLanguage();
  const { openTab } = useBrowser();

  return (
    <div className="mb-6 space-y-4">
      {/* Live Market Bar */}
      <div className="bg-gradient-to-r from-emerald-900/20 via-teal-900/10 to-slate-900/20 dark:from-emerald-950/40 dark:via-slate-900 dark:to-slate-950 border border-emerald-500/20 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="font-semibold text-emerald-600 dark:text-emerald-400">
            {lang === 'ar' ? 'رصد الأسعار الفوري مباشر اليوم (31 أكتوبر 2026):' : 'Live Market Monitor (Oct 31, 2026):'}
          </span>
          <span className="text-slate-600 dark:text-slate-300">
            {lang === 'ar'
              ? '5 مصادر بيانات رسمية متصلة • 100% أسعار موثقة ومحدثة'
              : '5 official verified sources connected • 100% verified pricing'}
          </span>
        </div>

        <button
          type="button"
          onClick={() =>
            openTab({
              title: 'مقارنة الأسعار العالمية',
              url: 'worldmarket://compare',
              type: 'compare',
            })
          }
          className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{lang === 'ar' ? 'استعراض المقارنة بين البلدان ←' : 'Browse Global Comparison Matrix →'}</span>
        </button>
      </div>

      {/* Grid of Top Price Drops */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="p-1 rounded bg-emerald-500/10 text-emerald-500">
              <TrendingDown className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
              {lang === 'ar' ? 'أكبر انخفاضات الأسعار هذا الأسبوع (عروض حقيقية)' : 'Top Price Drops This Week (Verified)'}
            </h3>
          </div>
          <span className="text-xs text-slate-500">تحديث مستمر من السوبرماركت ومستودعات الجملة</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {priceDrops.slice(0, 3).map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectProduct(item)}
              className="group bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 hover:border-emerald-500/50 hover:shadow-md transition-all cursor-pointer flex gap-3 relative overflow-hidden"
            >
              <div className="absolute top-2 end-2">
                <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  <TrendingDown className="w-3 h-3" />
                  {item.changePercentWeekly}%
                </span>
              </div>

              <img
                src={item.imageUrl}
                alt={item.productNameAr}
                className="w-16 h-16 rounded-lg object-cover bg-slate-100 dark:bg-slate-800 shrink-0"
              />

              <div className="flex-1 min-w-0 pe-12">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate group-hover:text-emerald-500 transition-colors">
                  {lang === 'ar' ? item.productNameAr : item.productNameEn}
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {item.storeOrSupplier} • {item.city} ({item.countryNameAr})
                </p>

                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400">
                    {item.retailPrice.toLocaleString()} {item.currency}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    جملة: {item.wholesalePrice.toLocaleString()} {item.currency}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
