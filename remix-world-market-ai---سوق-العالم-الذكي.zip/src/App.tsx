/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  LanguageProvider,
  useLanguage,
} from './contexts/LanguageContext.tsx';
import { ThemeProvider } from './contexts/ThemeContext.tsx';
import { AuthProvider, useAuth } from './contexts/AuthContext.tsx';
import { BrowserProvider, useBrowser } from './contexts/BrowserContext.tsx';
import { BrowserHeader } from './components/BrowserHeader.tsx';
import { SubNavbar } from './components/SubNavbar.tsx';
import { MarketMovers } from './components/MarketMovers.tsx';
import { ProductCard } from './components/ProductCard.tsx';
import { PriceComparisonModal } from './components/PriceComparisonModal.tsx';
import { BarcodeScannerModal } from './components/BarcodeScannerModal.tsx';
import { PriceHistoryModal } from './components/PriceHistoryModal.tsx';
import { PriceAlertsModal } from './components/PriceAlertsModal.tsx';
import { AiAssistantModal } from './components/AiAssistantModal.tsx';
import { DeveloperOffice } from './components/DeveloperOffice.tsx';
import { WorldWallet } from './components/WorldWallet.tsx';
import { SupplierPortal } from './components/SupplierPortal.tsx';
import { AdminPanel } from './components/AdminPanel.tsx';
import { ReportPriceModal } from './components/ReportPriceModal.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { ProductPrice } from './types/index.ts';
import {
  Sparkles,
  Bot,
  Filter,
  Layers,
  Search,
  Scale,
  Scan,
  TrendingDown,
  Building2,
  RefreshCw,
} from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { lang, t } = useLanguage();
  const {
    activeTab,
    openTab,
    selectedCountry,
    selectedCurrency,
    searchQuery,
  } = useBrowser();

  const [products, setProducts] = useState<ProductPrice[]>([]);
  const [priceDrops, setPriceDrops] = useState<ProductPrice[]>([]);
  const [priceHikes, setPriceHikes] = useState<ProductPrice[]>([]);
  const [wholesaleDeals, setWholesaleDeals] = useState<ProductPrice[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Category filter
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [filterType, setFilterType] = useState<'all' | 'supermarket' | 'wholesaler'>('all');

  // Modals state
  const [showScanner, setShowScanner] = useState<boolean>(false);
  const [showAi, setShowAi] = useState<boolean>(false);
  const [showAuth, setShowAuth] = useState<boolean>(false);
  const [showAlerts, setShowAlerts] = useState<boolean>(false);
  const [compareProduct, setCompareProduct] = useState<ProductPrice | null>(null);
  const [historyProduct, setHistoryProduct] = useState<ProductPrice | null>(null);
  const [alertProduct, setAlertProduct] = useState<ProductPrice | null>(null);
  const [reportProduct, setReportProduct] = useState<ProductPrice | null>(null);

  // Load products & movers
  const fetchProducts = async () => {
    setLoading(true);
    try {
      const q = activeTab.type === 'search' && activeTab.data?.query ? activeTab.data.query : searchQuery;
      const params = new URLSearchParams();
      if (q) params.set('search', q);
      if (selectedCategory !== 'all') params.set('category', selectedCategory);
      if (selectedCountry !== 'all') params.set('country', selectedCountry);
      if (filterType !== 'all') params.set('type', filterType);

      const res = await fetch(`/api/products?${params.toString()}`);
      const data = await res.json();
      if (data.success) {
        setProducts(data.products || []);
      }

      // Fetch market movers
      const moverRes = await fetch('/api/market-movers');
      const moverData = await moverRes.json();
      if (moverData.success) {
        setPriceDrops(moverData.priceDrops || []);
        setPriceHikes(moverData.priceHikes || []);
        setWholesaleDeals(moverData.wholesaleDeals || []);
      }
    } catch (e) {
      console.error('Failed to load products', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [selectedCategory, selectedCountry, filterType, activeTab, searchQuery]);

  const categories = [
    { id: 'all', nameAr: 'جميع السلع الغذائية', nameEn: 'All Staples' },
    { id: 'grains', nameAr: '🌾 أرز، سكر، دقيق', nameEn: '🌾 Rice, Sugar & Flour' },
    { id: 'oils', nameAr: '🌻 زيوت الطبخ والسمن', nameEn: '🌻 Cooking Oils' },
    { id: 'dairy', nameAr: '🥛 حليب وألبان', nameEn: '🥛 Milk & Dairy' },
    { id: 'meat', nameAr: '🥩 لحوم ودواجن', nameEn: '🥩 Meat & Poultry' },
    { id: 'cleaning', nameAr: '🧼 منظفات وصابون', nameEn: '🧼 Detergents' },
    { id: 'beverages', nameAr: '☕ شاي ومشروبات', nameEn: '☕ Tea & Drinks' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* 1. Modern Browser Header */}
      <BrowserHeader
        onOpenScanner={() => setShowScanner(true)}
        onOpenAi={() => setShowAi(true)}
        onOpenAuth={() => setShowAuth(true)}
        onOpenAlerts={() => setShowAlerts(true)}
      />

      {/* 2. Sub Navigation */}
      <SubNavbar />

      {/* 3. Main Workspace / Tab Body */}
      <main className="flex-1 p-3 sm:p-6 max-w-7xl w-full mx-auto">
        {/* VIEW 1: HOME & CATALOG */}
        {activeTab.type === 'home' && (
          <div className="space-y-6">
            {/* Market Movers Ticker */}
            <MarketMovers
              priceDrops={priceDrops}
              priceHikes={priceHikes}
              onSelectProduct={(p) => setCompareProduct(p)}
              onOpenCompare={(p) => setCompareProduct(p)}
            />

            {/* Category Pills & Filters */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
                {categories.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setSelectedCategory(c.id)}
                    className={`px-3 py-1.5 rounded-full text-xs font-semibold shrink-0 transition-all ${
                      selectedCategory === c.id
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50'
                    }`}
                  >
                    {lang === 'ar' ? c.nameAr : c.nameEn}
                  </button>
                ))}
              </div>

              {/* Wholesale vs Retail Toggle */}
              <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setFilterType('all')}
                  className={`px-2.5 py-1 rounded-lg font-medium ${
                    filterType === 'all'
                      ? 'bg-slate-100 dark:bg-slate-800 font-bold text-slate-900 dark:text-white'
                      : 'text-slate-500'
                  }`}
                >
                  الكل
                </button>
                <button
                  type="button"
                  onClick={() => setFilterType('supermarket')}
                  className={`px-2.5 py-1 rounded-lg font-medium ${
                    filterType === 'supermarket'
                      ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold'
                      : 'text-slate-500'
                  }`}
                >
                  سوبرماركت (تجزئة)
                </button>
                <button
                  type="button"
                  onClick={() => setFilterType('wholesaler')}
                  className={`px-2.5 py-1 rounded-lg font-medium ${
                    filterType === 'wholesaler'
                      ? 'bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 font-bold'
                      : 'text-slate-500'
                  }`}
                >
                  موردين (جملة)
                </button>
              </div>
            </div>

            {/* Products Grid */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  قائمة السلع والأسعار الموثقة ({products.length} سلعة متوفرة)
                </span>
                <button
                  type="button"
                  onClick={fetchProducts}
                  className="flex items-center gap-1 text-xs text-slate-400 hover:text-emerald-500"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>تحديث فوري</span>
                </button>
              </div>

              {products.length === 0 ? (
                <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
                    لم يتم العثور على سلع تطابق المعايير المحددة.
                  </p>
                  <p className="text-xs text-slate-500">
                    يمكنك تجربة إزالة الفلاتر أو استخدام ماسح الباركود للبحث عن رمز جديد.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCategory('all');
                      setFilterType('all');
                    }}
                    className="px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl"
                  >
                    عرض جميع السلع
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {products.map((item) => (
                    <ProductCard
                      key={item.id}
                      product={item}
                      onOpenCompare={(p) => setCompareProduct(p)}
                      onOpenHistory={(p) => setHistoryProduct(p)}
                      onOpenAlert={(p) => setAlertProduct(p)}
                      onReportMisleading={(p) => setReportProduct(p)}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* VIEW 2: ADVANCED SEARCH */}
        {activeTab.type === 'search' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Search className="w-5 h-5 text-emerald-500" />
                محرك البحث المتقدم عن السلع والأسعار
              </h2>
              <p className="text-xs text-slate-500">
                ابحث بالاسم، الماركة، الباركود، البلد، أو قارن أسعار الجملة والتجزئة.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {products.map((item) => (
                <ProductCard
                  key={item.id}
                  product={item}
                  onOpenCompare={(p) => setCompareProduct(p)}
                  onOpenHistory={(p) => setHistoryProduct(p)}
                  onOpenAlert={(p) => setAlertProduct(p)}
                  onReportMisleading={(p) => setReportProduct(p)}
                />
              ))}
            </div>
          </div>
        )}

        {/* VIEW 3: GLOBAL PRICE COMPARISON */}
        {activeTab.type === 'compare' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Scale className="w-5 h-5 text-emerald-500" />
                المقارنة العالمية لأسعار السلع الأساسية
              </h2>
              <p className="text-xs text-slate-500">
                اختر أي سلعة أدناه لاستعراض جدول المقارنة الفعلي بين مختلف البلدان (اليمن، السعودية، مصر، الإمارات) بأسعار الصرف الحية.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {products.map((item) => (
                <ProductCard
                  key={item.id}
                  product={item}
                  onOpenCompare={(p) => setCompareProduct(p)}
                  onOpenHistory={(p) => setHistoryProduct(p)}
                  onOpenAlert={(p) => setAlertProduct(p)}
                  onReportMisleading={(p) => setReportProduct(p)}
                />
              ))}
            </div>
          </div>
        )}

        {/* VIEW 4: WHOLESALE & SUPPLIERS */}
        {activeTab.type === 'wholesale' && (
          <SupplierPortal onProductAdded={fetchProducts} />
        )}

        {/* VIEW 5: PRICE ALERTS */}
        {activeTab.type === 'alerts' && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-amber-500" />
                متابعة حركة الأسعار والتنبيهات المخصصة
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                حدد السعر المستهدف لأي سلعة ليصلك إشعار فوري عند انخفاضها في الأسواق.
              </p>
            </div>
            <PriceAlertsModal onClose={() => openTab({ title: 'الرئيسية', url: 'worldmarket://home', type: 'home' })} />
          </div>
        )}

        {/* VIEW 6: WORLD WALLET */}
        {activeTab.type === 'wallet' && <WorldWallet />}

        {/* VIEW 7: AI DEVELOPER OFFICE */}
        {activeTab.type === 'dev' && <DeveloperOffice />}

        {/* VIEW 8: ADMIN PANEL */}
        {activeTab.type === 'admin' && <AdminPanel />}
      </main>

      {/* Floating Action Button for AI Assistant */}
      <div className="fixed bottom-5 end-5 z-40">
        <button
          type="button"
          onClick={() => setShowAi(true)}
          className="group flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-500 hover:to-teal-500 text-white rounded-full shadow-2xl transition-all transform hover:scale-105"
        >
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
          </span>
          <Bot className="w-5 h-5" />
          <span className="text-xs font-bold tracking-wide">
            {lang === 'ar' ? 'المساعد الذكي' : 'AI Assistant'}
          </span>
        </button>
      </div>

      {/* MODALS */}
      {showScanner && (
        <BarcodeScannerModal
          onClose={() => setShowScanner(false)}
          onSelectProduct={(p) => setCompareProduct(p)}
          onOpenAlert={(p) => setAlertProduct(p)}
        />
      )}

      {showAi && (
        <AiAssistantModal
          onClose={() => setShowAi(false)}
          onSelectProduct={(p) => setCompareProduct(p)}
          onOpenCompare={(p) => setCompareProduct(p)}
          onOpenAlert={(p) => setAlertProduct(p)}
        />
      )}

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}

      {showAlerts && (
        <PriceAlertsModal
          initialProduct={alertProduct}
          onClose={() => {
            setShowAlerts(false);
            setAlertProduct(null);
          }}
        />
      )}

      {alertProduct && (
        <PriceAlertsModal
          initialProduct={alertProduct}
          onClose={() => setAlertProduct(null)}
        />
      )}

      {compareProduct && (
        <PriceComparisonModal
          product={compareProduct}
          onClose={() => setCompareProduct(null)}
        />
      )}

      {historyProduct && (
        <PriceHistoryModal
          product={historyProduct}
          onClose={() => setHistoryProduct(null)}
        />
      )}

      {reportProduct && (
        <ReportPriceModal
          product={reportProduct}
          onClose={() => setReportProduct(null)}
        />
      )}

      {/* Footer */}
      <footer className="mt-12 py-6 border-t border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-slate-800 dark:text-slate-200 font-mono">
              WORLD MARKET AI
            </span>
            <span>•</span>
            <span>سوق العالم الذكي للسلع والأسعار</span>
          </div>
          <div>
            <span>تحديثات مستمرة لأسواق اليمن، السعودية، مصر، الإمارات • دقة موثقة 100%</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <BrowserProvider>
            <MainAppContent />
          </BrowserProvider>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
