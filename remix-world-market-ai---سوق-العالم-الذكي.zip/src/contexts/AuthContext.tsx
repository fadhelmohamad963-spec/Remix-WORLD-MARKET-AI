import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserAccount } from '../types/index.ts';

interface AuthContextType {
  user: UserAccount | null;
  usersList: UserAccount[];
  token: string | null;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: Partial<UserAccount> & { password: string }) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  switchUserRole: (role: UserAccount['role']) => void;
  exportUserData: () => void;
  deleteAccount: () => Promise<boolean>;
  refreshUsers: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserAccount | null>(null);
  const [usersList, setUsersList] = useState<UserAccount[]>([]);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('wm_token'));

  const fetchUsers = async () => {
    try {
      const res = await fetch('/api/auth/users');
      const data = await res.json();
      if (data.success) {
        setUsersList(data.users);
        // Default to the Owner/Developer account if not logged in
        if (!user && data.users.length > 0) {
          const savedUserId = localStorage.getItem('wm_user_id');
          const target = data.users.find((u: UserAccount) => u.id === savedUserId) || data.users[0];
          setUser(target);
        }
      }
    } catch (e) {
      console.error('Failed to load users', e);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const login = async (email: string, pass: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass }),
      });
      const data = await res.json();
      if (data.success) {
        setUser(data.user);
        setToken(data.token);
        localStorage.setItem('wm_token', data.token);
        localStorage.setItem('wm_user_id', data.user.id);
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const register = async (data: Partial<UserAccount> & { password: string }) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const resData = await res.json();
      if (resData.success) {
        setUser(resData.user);
        setToken(resData.token);
        localStorage.setItem('wm_token', resData.token);
        localStorage.setItem('wm_user_id', resData.user.id);
        await fetchUsers();
        return { success: true };
      }
      return { success: false, error: resData.error };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('wm_token');
    localStorage.removeItem('wm_user_id');
  };

  const switchUserRole = (targetRole: UserAccount['role']) => {
    const matched = usersList.find((u) => u.role === targetRole);
    if (matched) {
      setUser(matched);
      localStorage.setItem('wm_user_id', matched.id);
    }
  };

  const exportUserData = () => {
    if (!user) return;
    const blob = new Blob([JSON.stringify(user, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `world_market_user_${user.email}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const deleteAccount = async () => {
    if (!user) return false;
    // simulated account cleanup
    logout();
    return true;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        usersList,
        token,
        login,
        register,
        logout,
        switchUserRole,
        exportUserData,
        deleteAccount,
        refreshUsers: fetchUsers,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
