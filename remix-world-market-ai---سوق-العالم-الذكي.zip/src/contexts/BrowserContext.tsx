import React, { createContext, useContext, useState } from 'react';
import { BrowserTab } from '../types/index.ts';

interface BrowserContextType {
  tabs: BrowserTab[];
  activeTabId: string;
  activeTab: BrowserTab;
  openTab: (tab: Omit<BrowserTab, 'id'>) => void;
  closeTab: (id: string, e?: React.MouseEvent) => void;
  setActiveTabId: (id: string) => void;
  browserUrl: string;
  setBrowserUrl: (url: string) => void;
  history: string[];
  bookmarks: { title: string; url: string; type: BrowserTab['type'] }[];
  addBookmark: (item: { title: string; url: string; type: BrowserTab['type'] }) => void;
  removeBookmark: (url: string) => void;
  selectedCountry: string;
  setSelectedCountry: (c: string) => void;
  selectedCurrency: string;
  setSelectedCurrency: (c: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

const DEFAULT_TABS: BrowserTab[] = [
  {
    id: 'tab-home',
    title: 'الرئيسية | WORLD MARKET AI',
    url: 'worldmarket://home',
    type: 'home',
  },
];

const BrowserContext = createContext<BrowserContextType | undefined>(undefined);

export const BrowserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tabs, setTabs] = useState<BrowserTab[]>(DEFAULT_TABS);
  const [activeTabId, setActiveTabId] = useState<string>('tab-home');
  const [browserUrl, setBrowserUrl] = useState<string>('worldmarket://home');
  const [history, setHistory] = useState<string[]>(['worldmarket://home']);
  const [bookmarks, setBookmarks] = useState<{ title: string; url: string; type: BrowserTab['type'] }[]>([
    { title: 'أسعار الأرز والسكر', url: 'worldmarket://search?q=أرز', type: 'search' },
    { title: 'عروض الجملة والتوريد', url: 'worldmarket://wholesale', type: 'wholesale' },
    { title: 'محفظة WORLD WALLET', url: 'worldmarket://wallet', type: 'wallet' },
  ]);

  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [selectedCurrency, setSelectedCurrency] = useState<string>('SAR');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  const openTab = (newTabData: Omit<BrowserTab, 'id'>) => {
    // Check if an identical tab already exists
    const existing = tabs.find((t) => t.type === newTabData.type && t.url === newTabData.url);
    if (existing) {
      setActiveTabId(existing.id);
      setBrowserUrl(existing.url);
      return;
    }

    const id = `tab-${Date.now()}`;
    const newTab: BrowserTab = { ...newTabData, id };
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(id);
    setBrowserUrl(newTab.url);
    setHistory((prev) => [newTab.url, ...prev.slice(0, 19)]);
  };

  const closeTab = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (tabs.length <= 1) return; // Keep at least one tab

    const newTabs = tabs.filter((t) => t.id !== id);
    setTabs(newTabs);

    if (activeTabId === id) {
      const nextActive = newTabs[newTabs.length - 1];
      setActiveTabId(nextActive.id);
      setBrowserUrl(nextActive.url);
    }
  };

  const addBookmark = (item: { title: string; url: string; type: BrowserTab['type'] }) => {
    if (!bookmarks.some((b) => b.url === item.url)) {
      setBookmarks((prev) => [...prev, item]);
    }
  };

  const removeBookmark = (url: string) => {
    setBookmarks((prev) => prev.filter((b) => b.url !== url));
  };

  return (
    <BrowserContext.Provider
      value={{
        tabs,
        activeTabId,
        activeTab,
        openTab,
        closeTab,
        setActiveTabId,
        browserUrl,
        setBrowserUrl,
        history,
        bookmarks,
        addBookmark,
        removeBookmark,
        selectedCountry,
        setSelectedCountry,
        selectedCurrency,
        setSelectedCurrency,
        searchQuery,
        setSearchQuery,
      }}
    >
      {children}
    </BrowserContext.Provider>
  );
};

export const useBrowser = () => {
  const context = useContext(BrowserContext);
  if (!context) throw new Error('useBrowser must be used within BrowserProvider');
  return context;
};
