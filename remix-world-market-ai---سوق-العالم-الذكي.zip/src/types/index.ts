/**
 * Shared Type Definitions for WORLD MARKET AI
 */

export interface PricePoint {
  date: string;
  retailPrice: number;
  wholesalePrice: number;
}

export interface ProductPrice {
  id: string;
  productId: string;
  productNameAr: string;
  productNameEn: string;
  category: 'grains' | 'oils' | 'dairy' | 'meat' | 'produce' | 'canned' | 'beverages' | 'cleaning' | 'spices';
  brand: string;
  barcode: string;
  packageSize: string;
  weightGramsOrMl: number;
  unit: 'kg' | 'g' | 'liter' | 'ml' | 'piece' | 'carton' | 'sack';
  countryCode: string;
  countryNameAr: string;
  countryNameEn: string;
  city: string;
  storeOrSupplier: string;
  supplierType: 'supermarket' | 'wholesaler' | 'distributor' | 'factory';
  retailPrice: number;
  wholesalePrice: number;
  minWholesaleQty: number;
  wholesaleUnit: string;
  currency: 'SAR' | 'YER' | 'EGP' | 'AED' | 'USD' | 'EUR' | 'TRY';
  shippingCost?: number;
  sourceName: string;
  sourceUrl: string;
  verified: boolean;
  verifiedBy?: string;
  lastUpdated: string;
  priceTrend: 'down' | 'up' | 'stable';
  changePercentWeekly: number;
  history: PricePoint[];
  inStock: boolean;
  imageUrl: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'retailer' | 'supplier' | 'reviewer' | 'admin' | 'owner';
  country: string;
  city: string;
  companyName?: string;
  isVerifiedSupplier?: boolean;
  createdAt: string;
  walletBalance: Record<string, number>;
}

export interface PriceAlert {
  id: string;
  userId: string;
  productId: string;
  productName: string;
  targetPrice: number;
  currency: string;
  direction: 'below' | 'above';
  isActive: boolean;
  triggeredAt?: string;
  createdAt: string;
}

export interface WalletTransaction {
  id: string;
  userId: string;
  recipientEmail?: string;
  recipientName?: string;
  type: 'transfer_out' | 'transfer_in' | 'demo_deposit' | 'escrow_hold';
  amount: number;
  fee: number;
  currency: string;
  status: 'completed' | 'pending' | 'failed';
  referenceNote: string;
  timestamp: string;
}

export interface DataSourceStatus {
  id: string;
  name: string;
  type: 'api' | 'scraper' | 'feed';
  country: string;
  status: 'online' | 'degraded' | 'offline';
  lastSync: string;
  recordsCount: number;
  latencyMs: number;
  errorRate: number;
}

export interface MisleadingPriceReport {
  id: string;
  priceId: string;
  productName: string;
  reportedBy: string;
  reason: string;
  reportedPrice: number;
  claimedActualPrice: number;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
}

export interface BrowserTab {
  id: string;
  title: string;
  icon?: string;
  url: string;
  type: 'home' | 'search' | 'compare' | 'scanner' | 'wholesale' | 'wallet' | 'dev' | 'admin' | 'alerts';
  data?: any;
}
