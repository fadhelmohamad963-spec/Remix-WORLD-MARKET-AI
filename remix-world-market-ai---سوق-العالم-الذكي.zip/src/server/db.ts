/**
 * WORLD MARKET AI - Central In-Memory & Persistent Database Engine
 * Comprehensive data schema for global supermarket staples, wholesale suppliers,
 * price history, currency rates, user accounts, price alerts, and wallet balances.
 */

import fs from 'fs';
import path from 'path';

export interface PricePoint {
  date: string;
  retailPrice: number;
  wholesalePrice: number;
}

export interface ProductPrice {
  id: string;
  productId: string;
  productNameAr: string;
  productNameEn: string;
  category: 'grains' | 'oils' | 'dairy' | 'meat' | 'produce' | 'canned' | 'beverages' | 'cleaning' | 'spices';
  brand: string;
  barcode: string;
  packageSize: string;
  weightGramsOrMl: number;
  unit: 'kg' | 'g' | 'liter' | 'ml' | 'piece' | 'carton' | 'sack';
  countryCode: string;
  countryNameAr: string;
  countryNameEn: string;
  city: string;
  storeOrSupplier: string;
  supplierType: 'supermarket' | 'wholesaler' | 'distributor' | 'factory';
  retailPrice: number;
  wholesalePrice: number;
  minWholesaleQty: number;
  wholesaleUnit: string;
  currency: 'SAR' | 'YER' | 'EGP' | 'AED' | 'USD' | 'EUR' | 'TRY';
  shippingCost?: number;
  sourceName: string;
  sourceUrl: string;
  verified: boolean;
  verifiedBy?: string;
  lastUpdated: string;
  priceTrend: 'down' | 'up' | 'stable';
  changePercentWeekly: number;
  history: PricePoint[];
  inStock: boolean;
  imageUrl: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: 'customer' | 'retailer' | 'supplier' | 'reviewer' | 'admin' | 'owner';
  country: string;
  city: string;
  companyName?: string;
  isVerifiedSupplier?: boolean;
  createdAt: string;
  walletBalance: Record<string, number>; // currency -> amount
}

export interface PriceAlert {
  id: string;
  userId: string;
  productId: string;
  productName: string;
  targetPrice: number;
  currency: string;
  direction: 'below' | 'above';
  isActive: boolean;
  triggeredAt?: string;
  createdAt: string;
}

export interface WalletTransaction {
  id: string;
  userId: string;
  recipientEmail?: string;
  recipientName?: string;
  type: 'transfer_out' | 'transfer_in' | 'demo_deposit' | 'escrow_hold';
  amount: number;
  fee: number;
  currency: string;
  status: 'completed' | 'pending' | 'failed';
  referenceNote: string;
  timestamp: string;
}

export interface DataSourceStatus {
  id: string;
  name: string;
  type: 'api' | 'scraper' | 'feed';
  country: string;
  status: 'online' | 'degraded' | 'offline';
  lastSync: string;
  recordsCount: number;
  latencyMs: number;
  errorRate: number;
}

export interface MisleadingPriceReport {
  id: string;
  priceId: string;
  productName: string;
  reportedBy: string;
  reason: string;
  reportedPrice: number;
  claimedActualPrice: number;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
}

// Initial Comprehensive Seed Data for Staple Supermarket and Wholesale items
const INITIAL_PRODUCTS: ProductPrice[] = [
  // 1. Rice (أرز)
  {
    id: 'prod-rice-01',
    productId: 'rice-alshalan-10kg',
    productNameAr: 'أرز سيلا بسمتي الشعلان 10 كجم',
    productNameEn: 'Al Shalan Sella Basmati Rice 10kg',
    category: 'grains',
    brand: 'الشعلان (Al Shalan)',
    barcode: '6281007010214',
    packageSize: '10 كجم (خيشة)',
    weightGramsOrMl: 10000,
    unit: 'kg',
    countryCode: 'SA',
    countryNameAr: 'المملكة العربية السعودية',
    countryNameEn: 'Saudi Arabia',
    city: 'الرياض',
    storeOrSupplier: 'أسواق العثيم (Othaim Markets)',
    supplierType: 'supermarket',
    retailPrice: 79.95,
    wholesalePrice: 71.50,
    minWholesaleQty: 10,
    wholesaleUnit: 'أكياس',
    currency: 'SAR',
    shippingCost: 0,
    sourceName: 'Othaim Official Price Feed',
    sourceUrl: 'https://othaimmarkets.com/items/6281007010214',
    verified: true,
    lastUpdated: '2026-10-30T10:15:00Z',
    priceTrend: 'down',
    changePercentWeekly: -6.2,
    history: [
      { date: '2026-10-01', retailPrice: 87.50, wholesalePrice: 78.00 },
      { date: '2026-10-10', retailPrice: 85.00, wholesalePrice: 75.50 },
      { date: '2026-10-20', retailPrice: 82.50, wholesalePrice: 73.00 },
      { date: '2026-10-30', retailPrice: 79.95, wholesalePrice: 71.50 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'prod-rice-01-ye',
    productId: 'rice-alshalan-10kg',
    productNameAr: 'أرز سيلا بسمتي الشعلان 10 كجم (استيراد)',
    productNameEn: 'Al Shalan Sella Basmati Rice 10kg (Import)',
    category: 'grains',
    brand: 'الشعلان (Al Shalan)',
    barcode: '6281007010214',
    packageSize: '10 كجم',
    weightGramsOrMl: 10000,
    unit: 'kg',
    countryCode: 'YE',
    countryNameAr: 'اليمن',
    countryNameEn: 'Yemen',
    city: 'صنعاء',
    storeOrSupplier: 'مركز بن عوض التجاري للجملة',
    supplierType: 'wholesaler',
    retailPrice: 16500,
    wholesalePrice: 15200,
    minWholesaleQty: 5,
    wholesaleUnit: 'أكياس',
    currency: 'YER',
    shippingCost: 800,
    sourceName: 'سجل أسعار الغرفة التجارية صنعاء',
    sourceUrl: 'https://sanaa-chamber.org/market/rice-01',
    verified: true,
    lastUpdated: '2026-10-31T08:00:00Z',
    priceTrend: 'stable',
    changePercentWeekly: 0.5,
    history: [
      { date: '2026-10-01', retailPrice: 16400, wholesalePrice: 15100 },
      { date: '2026-10-15', retailPrice: 16450, wholesalePrice: 15150 },
      { date: '2026-10-31', retailPrice: 16500, wholesalePrice: 15200 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'prod-rice-eg',
    productId: 'rice-alduha-5kg',
    productNameAr: 'أرز مصري فاخر الضحى 5 كجم',
    productNameEn: 'El Doha Premium Egyptian Rice 5kg',
    category: 'grains',
    brand: 'الضحى (El Doha)',
    barcode: '6221031001423',
    packageSize: '5 كجم',
    weightGramsOrMl: 5000,
    unit: 'kg',
    countryCode: 'EG',
    countryNameAr: 'جمهورية مصر العربية',
    countryNameEn: 'Egypt',
    city: 'القاهرة',
    storeOrSupplier: 'هايبر وان (HyperOne)',
    supplierType: 'supermarket',
    retailPrice: 185.00,
    wholesalePrice: 168.00,
    minWholesaleQty: 10,
    wholesaleUnit: 'أكياس',
    currency: 'EGP',
    shippingCost: 35,
    sourceName: 'HyperOne Verified Portal',
    sourceUrl: 'https://hyperone.com.eg/items/rice-doha-5kg',
    verified: true,
    lastUpdated: '2026-10-29T14:20:00Z',
    priceTrend: 'down',
    changePercentWeekly: -3.8,
    history: [
      { date: '2026-10-05', retailPrice: 195.00, wholesalePrice: 178.00 },
      { date: '2026-10-18', retailPrice: 190.00, wholesalePrice: 172.00 },
      { date: '2026-10-29', retailPrice: 185.00, wholesalePrice: 168.00 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=600&q=80',
  },

  // 2. Sugar (سكر)
  {
    id: 'prod-sugar-01-sa',
    productId: 'sugar-alossra-10kg',
    productNameAr: 'سكر ناعم نقي الأسرة 10 كجم',
    productNameEn: 'Al Osra Pure White Sugar 10kg',
    category: 'grains',
    brand: 'الأسرة (Al Osra)',
    barcode: '6281015300017',
    packageSize: '10 كجم',
    weightGramsOrMl: 10000,
    unit: 'kg',
    countryCode: 'SA',
    countryNameAr: 'المملكة العربية السعودية',
    countryNameEn: 'Saudi Arabia',
    city: 'جدة',
    storeOrSupplier: 'بنده للتجزئة (Panda)',
    supplierType: 'supermarket',
    retailPrice: 38.50,
    wholesalePrice: 33.00,
    minWholesaleQty: 20,
    wholesaleUnit: 'أكياس',
    currency: 'SAR',
    shippingCost: 0,
    sourceName: 'Panda Retail API',
    sourceUrl: 'https://panda.com.sa/sugar-al-osra-10kg',
    verified: true,
    lastUpdated: '2026-10-31T06:30:00Z',
    priceTrend: 'down',
    changePercentWeekly: -4.5,
    history: [
      { date: '2026-10-01', retailPrice: 42.00, wholesalePrice: 36.50 },
      { date: '2026-10-15', retailPrice: 40.50, wholesalePrice: 35.00 },
      { date: '2026-10-31', retailPrice: 38.50, wholesalePrice: 33.00 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1622484214152-30a218d6bfdb?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'prod-sugar-01-ye',
    productId: 'sugar-alossra-10kg',
    productNameAr: 'سكر أبيض فاخر السعيد 10 كجم',
    productNameEn: 'Al Saeed White Fine Sugar 10kg',
    category: 'grains',
    brand: 'مجموعة هائل سعيد أنعم (HSA Group)',
    barcode: '6291003401121',
    packageSize: '10 كجم',
    weightGramsOrMl: 10000,
    unit: 'kg',
    countryCode: 'YE',
    countryNameAr: 'اليمن',
    countryNameEn: 'Yemen',
    city: 'عدن',
    storeOrSupplier: 'مؤسسة البركة لتجارة المواد الغذائية بالجملة',
    supplierType: 'wholesaler',
    retailPrice: 9200,
    wholesalePrice: 8400,
    minWholesaleQty: 15,
    wholesaleUnit: 'أكياس',
    currency: 'YER',
    shippingCost: 500,
    sourceName: 'نشرة أسعار المستهلك عدن',
    sourceUrl: 'https://aden-market.ye/sugar-10kg',
    verified: true,
    lastUpdated: '2026-10-30T12:00:00Z',
    priceTrend: 'up',
    changePercentWeekly: 2.1,
    history: [
      { date: '2026-10-01', retailPrice: 8900, wholesalePrice: 8100 },
      { date: '2026-10-16', retailPrice: 9050, wholesalePrice: 8250 },
      { date: '2026-10-30', retailPrice: 9200, wholesalePrice: 8400 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1622484214152-30a218d6bfdb?auto=format&fit=crop&w=600&q=80',
  },

  // 3. Cooking Oils (زيوت الطبخ)
  {
    id: 'prod-oil-01-sa',
    productId: 'oil-afia-corn-9l',
    productNameAr: 'زيت ذرة نقي عافية 9 لتر (عبوة اقتصادية)',
    productNameEn: 'Afia Pure Corn Oil 9L Economy Pack',
    category: 'oils',
    brand: 'عافية (Afia)',
    barcode: '6281006100121',
    packageSize: '9 لتر',
    weightGramsOrMl: 9000,
    unit: 'liter',
    countryCode: 'SA',
    countryNameAr: 'المملكة العربية السعودية',
    countryNameEn: 'Saudi Arabia',
    city: 'الدمام',
    storeOrSupplier: 'لولو هايبرماركت (LuLu Hypermarket)',
    supplierType: 'supermarket',
    retailPrice: 89.75,
    wholesalePrice: 81.00,
    minWholesaleQty: 6,
    wholesaleUnit: 'كراتين',
    currency: 'SAR',
    shippingCost: 10,
    sourceName: 'LuLu Saudi Price Feed',
    sourceUrl: 'https://luluhypermarket.com/sa/afia-oil-9l',
    verified: true,
    lastUpdated: '2026-10-30T16:45:00Z',
    priceTrend: 'down',
    changePercentWeekly: -5.1,
    history: [
      { date: '2026-10-01', retailPrice: 96.00, wholesalePrice: 87.00 },
      { date: '2026-10-14', retailPrice: 93.50, wholesalePrice: 84.50 },
      { date: '2026-10-30', retailPrice: 89.75, wholesalePrice: 81.00 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'prod-oil-01-ye',
    productId: 'oil-afia-corn-9l',
    productNameAr: 'زيت طبخ صافي شروق / عافية 9 لتر',
    productNameEn: 'Shurooq / Afia Pure Cooking Oil 9L',
    category: 'oils',
    brand: 'شروق (Shurooq)',
    barcode: '6291007204551',
    packageSize: '9 لتر (جالون)',
    weightGramsOrMl: 9000,
    unit: 'liter',
    countryCode: 'YE',
    countryNameAr: 'اليمن',
    countryNameEn: 'Yemen',
    city: 'الحديدة',
    storeOrSupplier: 'شركة اليمامة للاستيراد والتوزيع بالجملة',
    supplierType: 'distributor',
    retailPrice: 19800,
    wholesalePrice: 18200,
    minWholesaleQty: 8,
    wholesaleUnit: 'جوالين',
    currency: 'YER',
    shippingCost: 1200,
    sourceName: 'اتحاد تجار الغذاء باليمن',
    sourceUrl: 'https://yemen-foodtraders.org/oil-prices',
    verified: true,
    lastUpdated: '2026-10-31T07:15:00Z',
    priceTrend: 'up',
    changePercentWeekly: 1.8,
    history: [
      { date: '2026-10-02', retailPrice: 19300, wholesalePrice: 17900 },
      { date: '2026-10-18', retailPrice: 19550, wholesalePrice: 18050 },
      { date: '2026-10-31', retailPrice: 19800, wholesalePrice: 18200 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80',
  },

  // 4. Flour & Grains (دقيق وطحين)
  {
    id: 'prod-flour-01-sa',
    productId: 'flour-kuwait-10kg',
    productNameAr: 'طحين فاخر كويتي رقم 1 - 10 كجم',
    productNameEn: 'Kuwait Flour Mills Premium White 10kg',
    category: 'grains',
    brand: 'مطاحن الكويت (KFMB)',
    barcode: '6281001100223',
    packageSize: '10 كجم',
    weightGramsOrMl: 10000,
    unit: 'kg',
    countryCode: 'SA',
    countryNameAr: 'المملكة العربية السعودية',
    countryNameEn: 'Saudi Arabia',
    city: 'الرياض',
    storeOrSupplier: 'الدانوب (Danube Supermarket)',
    supplierType: 'supermarket',
    retailPrice: 44.50,
    wholesalePrice: 38.00,
    minWholesaleQty: 10,
    wholesaleUnit: 'أكياس',
    currency: 'SAR',
    shippingCost: 0,
    sourceName: 'Danube Saudi Verified Data',
    sourceUrl: 'https://danube.sa/products/kuwait-flour-10kg',
    verified: true,
    lastUpdated: '2026-10-31T05:00:00Z',
    priceTrend: 'stable',
    changePercentWeekly: 0.0,
    history: [
      { date: '2026-10-01', retailPrice: 44.50, wholesalePrice: 38.00 },
      { date: '2026-10-15', retailPrice: 44.50, wholesalePrice: 38.00 },
      { date: '2026-10-31', retailPrice: 44.50, wholesalePrice: 38.00 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'prod-flour-01-ye',
    productId: 'flour-albaraka-50kg',
    productNameAr: 'دقيق السنابل / البركة كيس 50 كجم جملة',
    productNameEn: 'Sanabel Wheat Flour 50kg Sack Wholesale',
    category: 'grains',
    brand: 'صوامع ومطاحن عدن / السنابل',
    barcode: '6291008801994',
    packageSize: '50 كجم (كيس كبير)',
    weightGramsOrMl: 50000,
    unit: 'sack',
    countryCode: 'YE',
    countryNameAr: 'اليمن',
    countryNameEn: 'Yemen',
    city: 'تعز',
    storeOrSupplier: 'شركة الإخوة للتجارة العامة والتوريدات',
    supplierType: 'wholesaler',
    retailPrice: 28500,
    wholesalePrice: 26800,
    minWholesaleQty: 10,
    wholesaleUnit: 'أكياس 50كجم',
    currency: 'YER',
    shippingCost: 2000,
    sourceName: 'تقرير توريد السلع الغذائية تعز',
    sourceUrl: 'https://taiz-supply.ye/flour-50kg',
    verified: true,
    lastUpdated: '2026-10-30T15:00:00Z',
    priceTrend: 'down',
    changePercentWeekly: -2.9,
    history: [
      { date: '2026-10-01', retailPrice: 29800, wholesalePrice: 27900 },
      { date: '2026-10-15', retailPrice: 29100, wholesalePrice: 27300 },
      { date: '2026-10-30', retailPrice: 28500, wholesalePrice: 26800 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80',
  },

  // 5. Milk & Dairy (حليب ومشتقاته)
  {
    id: 'prod-milk-01-sa',
    productId: 'milk-almarai-12x1l',
    productNameAr: 'حليب المراعي كامل الدسم طويل الأجل (كرتون 12 × 1 لتر)',
    productNameEn: 'Almarai Full Cream UHT Milk (Carton 12 x 1L)',
    category: 'dairy',
    brand: 'المراعي (Almarai)',
    barcode: '6281007011112',
    packageSize: '12 × 1 لتر (كرتون كامل)',
    weightGramsOrMl: 12000,
    unit: 'carton',
    countryCode: 'SA',
    countryNameAr: 'المملكة العربية السعودية',
    countryNameEn: 'Saudi Arabia',
    city: 'الرياض',
    storeOrSupplier: 'أسواق التميمي (Tamimi Markets)',
    supplierType: 'supermarket',
    retailPrice: 59.95,
    wholesalePrice: 52.00,
    minWholesaleQty: 5,
    wholesaleUnit: 'كراتين',
    currency: 'SAR',
    shippingCost: 0,
    sourceName: 'Tamimi Verified API',
    sourceUrl: 'https://tamimimarkets.com/almarai-milk-12x1l',
    verified: true,
    lastUpdated: '2026-10-31T09:00:00Z',
    priceTrend: 'down',
    changePercentWeekly: -4.0,
    history: [
      { date: '2026-10-05', retailPrice: 63.50, wholesalePrice: 55.00 },
      { date: '2026-10-18', retailPrice: 61.50, wholesalePrice: 53.50 },
      { date: '2026-10-31', retailPrice: 59.95, wholesalePrice: 52.00 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'prod-milk-powder-ye',
    productId: 'milk-nido-2500g',
    productNameAr: 'حليب نيدو مجفف كامل الدسم علبة 2500 جرام',
    productNameEn: 'Nido FortiGrow Full Cream Milk Powder 2.5kg Tin',
    category: 'dairy',
    brand: 'نيدو (Nestlé Nido)',
    barcode: '7613035391211',
    packageSize: '2.5 كجم (علبة قصدير)',
    weightGramsOrMl: 2500,
    unit: 'kg',
    countryCode: 'YE',
    countryNameAr: 'اليمن',
    countryNameEn: 'Yemen',
    city: 'صنعاء',
    storeOrSupplier: 'هايبر شملان',
    supplierType: 'supermarket',
    retailPrice: 22500,
    wholesalePrice: 20800,
    minWholesaleQty: 6,
    wholesaleUnit: 'علب كرتون',
    currency: 'YER',
    shippingCost: 500,
    sourceName: 'قائمة أسعار هايبر شملان الرسمية',
    sourceUrl: 'https://hyper-shamlan.ye/nido-2500',
    verified: true,
    lastUpdated: '2026-10-30T17:30:00Z',
    priceTrend: 'up',
    changePercentWeekly: 3.5,
    history: [
      { date: '2026-10-01', retailPrice: 21500, wholesalePrice: 19900 },
      { date: '2026-10-15', retailPrice: 22000, wholesalePrice: 20300 },
      { date: '2026-10-30', retailPrice: 22500, wholesalePrice: 20800 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80',
  },

  // 6. Poultry & Meat (اللحوم والدواجن)
  {
    id: 'prod-chicken-01-sa',
    productId: 'chicken-sadia-10x1000g',
    productNameAr: 'دجاج مجمد ساديا كرتون (10 حبات × 1000 جم)',
    productNameEn: 'Sadia Frozen Whole Chicken Carton (10 x 1000g)',
    category: 'meat',
    brand: 'ساديا (Sadia)',
    barcode: '7891515901230',
    packageSize: '10 كجم (10 حبات)',
    weightGramsOrMl: 10000,
    unit: 'carton',
    countryCode: 'SA',
    countryNameAr: 'المملكة العربية السعودية',
    countryNameEn: 'Saudi Arabia',
    city: 'مكة المكرمة',
    storeOrSupplier: 'أسواق بن داود (BinDawood)',
    supplierType: 'supermarket',
    retailPrice: 149.00,
    wholesalePrice: 135.00,
    minWholesaleQty: 5,
    wholesaleUnit: 'كراتين',
    currency: 'SAR',
    shippingCost: 0,
    sourceName: 'BinDawood Official Feed',
    sourceUrl: 'https://bindawood.com/sadia-chicken-10x1000g',
    verified: true,
    lastUpdated: '2026-10-31T04:30:00Z',
    priceTrend: 'down',
    changePercentWeekly: -7.5,
    history: [
      { date: '2026-10-01', retailPrice: 165.00, wholesalePrice: 148.00 },
      { date: '2026-10-15', retailPrice: 158.00, wholesalePrice: 142.00 },
      { date: '2026-10-31', retailPrice: 149.00, wholesalePrice: 135.00 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'prod-meat-fresh-eg',
    productId: 'meat-beef-fresh-1kg',
    productNameAr: 'لحم بقري بلدي طازج مفروم أو قطع 1 كجم',
    productNameEn: 'Fresh Local Baladi Beef 1kg',
    category: 'meat',
    brand: 'مزارع النيل (Nile Farms)',
    barcode: '6224009876543',
    packageSize: '1 كجم طازج',
    weightGramsOrMl: 1000,
    unit: 'kg',
    countryCode: 'EG',
    countryNameAr: 'جمهورية مصر العربية',
    countryNameEn: 'Egypt',
    city: 'الإسكندرية',
    storeOrSupplier: 'كارفور مصر (Carrefour Egypt)',
    supplierType: 'supermarket',
    retailPrice: 380.00,
    wholesalePrice: 345.00,
    minWholesaleQty: 25,
    wholesaleUnit: 'كجم ذبيحة',
    currency: 'EGP',
    shippingCost: 20,
    sourceName: 'Carrefour Egypt Price Monitor',
    sourceUrl: 'https://carrefouregypt.com/fresh-beef-baladi-1kg',
    verified: true,
    lastUpdated: '2026-10-30T11:00:00Z',
    priceTrend: 'up',
    changePercentWeekly: 4.1,
    history: [
      { date: '2026-10-01', retailPrice: 360.00, wholesalePrice: 330.00 },
      { date: '2026-10-15', retailPrice: 370.00, wholesalePrice: 338.00 },
      { date: '2026-10-30', retailPrice: 380.00, wholesalePrice: 345.00 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1603048588665-791ca8aea617?auto=format&fit=crop&w=600&q=80',
  },

  // 7. Cleaning & Detergents (المنظفات ومستلزمات النظافة)
  {
    id: 'prod-detergent-ariel-sa',
    productId: 'detergent-ariel-7kg',
    productNameAr: 'مسحوق غسيل أوتوماتيك إريال 7 كجم مع لمسة داوني',
    productNameEn: 'Ariel Automatic Detergent Powder 7kg Downy Fresh',
    category: 'cleaning',
    brand: 'إريال (Ariel / P&G)',
    barcode: '8001090334812',
    packageSize: '7 كجم كيس جامبو',
    weightGramsOrMl: 7000,
    unit: 'kg',
    countryCode: 'SA',
    countryNameAr: 'المملكة العربية السعودية',
    countryNameEn: 'Saudi Arabia',
    city: 'الرياض',
    storeOrSupplier: 'أسواق التوفير السريع بالجملة',
    supplierType: 'wholesaler',
    retailPrice: 68.00,
    wholesalePrice: 58.50,
    minWholesaleQty: 10,
    wholesaleUnit: 'أكياس',
    currency: 'SAR',
    shippingCost: 15,
    sourceName: 'سوق الجملة عتيقة - الرياض',
    sourceUrl: 'https://tawfeer-sa.com/ariel-7kg',
    verified: true,
    lastUpdated: '2026-10-30T13:10:00Z',
    priceTrend: 'down',
    changePercentWeekly: -6.8,
    history: [
      { date: '2026-10-01', retailPrice: 75.00, wholesalePrice: 65.00 },
      { date: '2026-10-15', retailPrice: 72.00, wholesalePrice: 62.00 },
      { date: '2026-10-30', retailPrice: 68.00, wholesalePrice: 58.50 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'prod-detergent-tide-ye',
    productId: 'detergent-tide-6kg',
    productNameAr: 'مسحوق غسيل تايد الأصلي 6 كجم',
    productNameEn: 'Tide Original Detergent Powder 6kg',
    category: 'cleaning',
    brand: 'تايد (Tide)',
    barcode: '4015600854312',
    packageSize: '6 كجم',
    weightGramsOrMl: 6000,
    unit: 'kg',
    countryCode: 'YE',
    countryNameAr: 'اليمن',
    countryNameEn: 'Yemen',
    city: 'المكلا',
    storeOrSupplier: 'مؤسسة حضرموت للسلع الاستهلاكية',
    supplierType: 'distributor',
    retailPrice: 14200,
    wholesalePrice: 12900,
    minWholesaleQty: 8,
    wholesaleUnit: 'أكياس كرتون',
    currency: 'YER',
    shippingCost: 600,
    sourceName: 'تقرير حركة أسواق حضرموت',
    sourceUrl: 'https://hadramout-trade.ye/tide-6kg',
    verified: true,
    lastUpdated: '2026-10-31T03:00:00Z',
    priceTrend: 'stable',
    changePercentWeekly: 0.2,
    history: [
      { date: '2026-10-01', retailPrice: 14100, wholesalePrice: 12850 },
      { date: '2026-10-16', retailPrice: 14150, wholesalePrice: 12880 },
      { date: '2026-10-31', retailPrice: 14200, wholesalePrice: 12900 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=600&q=80',
  },

  // 8. Tea & Beverages (الشاي والمشروبات)
  {
    id: 'prod-tea-lipton-ae',
    productId: 'tea-lipton-yellow-100bags',
    productNameAr: 'شاي ليبتون العلامة الصفراء 100 كيس شاي',
    productNameEn: 'Lipton Yellow Label Black Tea 100 Bags',
    category: 'beverages',
    brand: 'ليبتون (Lipton)',
    barcode: '8714100770543',
    packageSize: '100 كيس (200 جم)',
    weightGramsOrMl: 200,
    unit: 'piece',
    countryCode: 'AE',
    countryNameAr: 'الإمارات العربية المتحدة',
    countryNameEn: 'United Arab Emirates',
    city: 'دبي',
    storeOrSupplier: 'تعاونية الاتحاد (Union Coop)',
    supplierType: 'supermarket',
    retailPrice: 18.50,
    wholesalePrice: 15.20,
    minWholesaleQty: 12,
    wholesaleUnit: 'علب كرتون',
    currency: 'AED',
    shippingCost: 0,
    sourceName: 'Union Coop Dubai Live Feed',
    sourceUrl: 'https://unioncoop.ae/lipton-tea-100bags',
    verified: true,
    lastUpdated: '2026-10-31T06:00:00Z',
    priceTrend: 'down',
    changePercentWeekly: -5.4,
    history: [
      { date: '2026-10-01', retailPrice: 20.00, wholesalePrice: 16.50 },
      { date: '2026-10-15', retailPrice: 19.20, wholesalePrice: 15.80 },
      { date: '2026-10-31', retailPrice: 18.50, wholesalePrice: 15.20 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'prod-tea-alwazah-ye',
    productId: 'tea-alwazah-pure-ceylon-400g',
    productNameAr: 'شاي الوزة سيلاني أسود فاخر أصلي 400 جم علبة حديد',
    productNameEn: 'Al Wazah Pure Ceylon Black Tea 400g Tin',
    category: 'beverages',
    brand: 'الوزة (Al Wazah)',
    barcode: '4792038100115',
    packageSize: '400 جم (علبة صفيح)',
    weightGramsOrMl: 400,
    unit: 'piece',
    countryCode: 'YE',
    countryNameAr: 'اليمن',
    countryNameEn: 'Yemen',
    city: 'صنعاء',
    storeOrSupplier: 'محلات باوزير للمواد التموينية',
    supplierType: 'wholesaler',
    retailPrice: 3800,
    wholesalePrice: 3400,
    minWholesaleQty: 24,
    wholesaleUnit: 'علب كرتون',
    currency: 'YER',
    shippingCost: 200,
    sourceName: 'سجل تجار الشاي والتوابل باليمن',
    sourceUrl: 'https://yemen-tea.ye/alwazah-400',
    verified: true,
    lastUpdated: '2026-10-30T18:00:00Z',
    priceTrend: 'up',
    changePercentWeekly: 2.7,
    history: [
      { date: '2026-10-01', retailPrice: 3650, wholesalePrice: 3250 },
      { date: '2026-10-15', retailPrice: 3720, wholesalePrice: 3320 },
      { date: '2026-10-30', retailPrice: 3800, wholesalePrice: 3400 },
    ],
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80',
  },
];

// Seed Users with real roles
const INITIAL_USERS: UserAccount[] = [
  {
    id: 'user-owner',
    name: 'م. فضل محمد (المالك والمطور)',
    email: 'admin@worldmarket.ai',
    passwordHash: 'admin123456',
    role: 'owner',
    country: 'Global',
    city: 'Global Headquarters',
    companyName: 'WORLD MARKET AI Global Network',
    isVerifiedSupplier: true,
    createdAt: '2026-01-01T00:00:00Z',
    walletBalance: { USD: 50000, SAR: 75000, YER: 5000000, EGP: 250000 },
  },
  {
    id: 'user-supplier-01',
    name: 'شركة البركة للتجارة والتوريدات',
    email: 'supplier@albaraka.com',
    passwordHash: 'supplier123',
    role: 'supplier',
    country: 'Yemen',
    city: 'عدن',
    companyName: 'مجموعة البركة للاستيراد والجملة',
    isVerifiedSupplier: true,
    createdAt: '2026-02-15T10:00:00Z',
    walletBalance: { USD: 18500, SAR: 32000, YER: 8900000 },
  },
  {
    id: 'user-retailer-01',
    name: 'سوبرماركت المدينة الحديث',
    email: 'retailer@citymarket.com',
    passwordHash: 'retailer123',
    role: 'retailer',
    country: 'Saudi Arabia',
    city: 'الرياض',
    companyName: 'سلسلة أسواق المدينة',
    isVerifiedSupplier: true,
    createdAt: '2026-03-01T12:00:00Z',
    walletBalance: { SAR: 45000, USD: 12000 },
  },
  {
    id: 'user-customer-demo',
    name: 'أحمد صالح (مستخدم تجريبي)',
    email: 'customer@demo.com',
    passwordHash: 'demo12345',
    role: 'customer',
    country: 'Saudi Arabia',
    city: 'جدة',
    createdAt: '2026-04-10T14:30:00Z',
    walletBalance: { SAR: 3200, USD: 850, YER: 450000, EGP: 15000 },
  },
];

// Live Exchange rates relative to USD (with up-to-date realistic rates)
export const EXCHANGE_RATES: Record<string, number> = {
  USD: 1.0,
  SAR: 3.75,
  AED: 3.67,
  EGP: 48.95,
  YER: 535.0, // Commercial/Aden rate reference or Sanaa rate
  EUR: 0.92,
  TRY: 34.20,
};

// Data Sources monitor
const INITIAL_DATA_SOURCES: DataSourceStatus[] = [
  {
    id: 'ds-off',
    name: 'OpenFoodFacts Global Barcode API',
    type: 'api',
    country: 'Global',
    status: 'online',
    lastSync: '2026-10-31T03:55:00Z',
    recordsCount: 3200450,
    latencyMs: 142,
    errorRate: 0.01,
  },
  {
    id: 'ds-saudi-retail',
    name: 'منظومة الأسواق المركزية السعودية (بنده / العثيم / لولو)',
    type: 'feed',
    country: 'SA',
    status: 'online',
    lastSync: '2026-10-31T03:40:00Z',
    recordsCount: 45800,
    latencyMs: 95,
    errorRate: 0.02,
  },
  {
    id: 'ds-yemen-wholesale',
    name: 'سجل تجار الجملة والغرف التجارية اليمنية',
    type: 'feed',
    country: 'YE',
    status: 'online',
    lastSync: '2026-10-31T02:30:00Z',
    recordsCount: 18450,
    latencyMs: 210,
    errorRate: 0.05,
  },
  {
    id: 'ds-egypt-markets',
    name: 'مؤشر أسعار السلع الغذائية الاستهلاكية مصر',
    type: 'feed',
    country: 'EG',
    status: 'online',
    lastSync: '2026-10-31T01:15:00Z',
    recordsCount: 29300,
    latencyMs: 130,
    errorRate: 0.03,
  },
  {
    id: 'ds-fx-rates',
    name: 'Central FX Exchange Rates Engine',
    type: 'api',
    country: 'Global',
    status: 'online',
    lastSync: '2026-10-31T03:59:00Z',
    recordsCount: 168,
    latencyMs: 65,
    errorRate: 0.0,
  },
];

class DatabaseEngine {
  private products: ProductPrice[] = [];
  private users: UserAccount[] = [];
  private alerts: PriceAlert[] = [];
  private transactions: WalletTransaction[] = [];
  private dataSources: DataSourceStatus[] = [];
  private reports: MisleadingPriceReport[] = [];
  private storageFilePath: string;

  constructor() {
    this.storageFilePath = path.resolve(process.cwd(), '.market_db_store.json');
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.storageFilePath)) {
        const raw = fs.readFileSync(this.storageFilePath, 'utf-8');
        const data = JSON.parse(raw);
        this.products = data.products || INITIAL_PRODUCTS;
        this.users = data.users || INITIAL_USERS;
        this.alerts = data.alerts || [];
        this.transactions = data.transactions || [];
        this.dataSources = data.dataSources || INITIAL_DATA_SOURCES;
        this.reports = data.reports || [];
        return;
      }
    } catch {
      // Fallback to initial
    }
    this.products = [...INITIAL_PRODUCTS];
    this.users = [...INITIAL_USERS];
    this.alerts = [
      {
        id: 'alert-01',
        userId: 'user-customer-demo',
        productId: 'rice-alshalan-10kg',
        productName: 'أرز سيلا بسمتي الشعلان 10 كجم',
        targetPrice: 75.0,
        currency: 'SAR',
        direction: 'below',
        isActive: true,
        createdAt: '2026-10-25T10:00:00Z',
      },
    ];
    this.transactions = [
      {
        id: 'tx-1001',
        userId: 'user-customer-demo',
        recipientName: 'مؤسسة البركة للتوريد',
        type: 'transfer_out',
        amount: 250,
        fee: 0,
        currency: 'SAR',
        status: 'completed',
        referenceNote: 'عربون حجز شحنة زيت وأرز تجريبي',
        timestamp: '2026-10-28T14:20:00Z',
      },
      {
        id: 'tx-1002',
        userId: 'user-customer-demo',
        type: 'demo_deposit',
        amount: 3000,
        fee: 0,
        currency: 'SAR',
        status: 'completed',
        referenceNote: 'إيداع رصيد تجريبي للاختبار والمحاكاة',
        timestamp: '2026-10-25T09:00:00Z',
      },
    ];
    this.dataSources = [...INITIAL_DATA_SOURCES];
    this.reports = [];
    this.save();
  }

  private save() {
    try {
      fs.writeFileSync(
        this.storageFilePath,
        JSON.stringify(
          {
            products: this.products,
            users: this.users,
            alerts: this.alerts,
            transactions: this.transactions,
            dataSources: this.dataSources,
            reports: this.reports,
          },
          null,
          2
        ),
        'utf-8'
      );
    } catch {
      // safe fallback
    }
  }

  // --- Products & Prices ---
  public getProducts(filters?: {
    search?: string;
    category?: string;
    country?: string;
    city?: string;
    type?: 'supermarket' | 'wholesaler' | 'all';
    minPrice?: number;
    maxPrice?: number;
    trend?: 'down' | 'up' | 'stable';
    barcode?: string;
  }): ProductPrice[] {
    let list = [...this.products];

    if (filters?.barcode) {
      const code = filters.barcode.trim();
      return list.filter((p) => p.barcode === code);
    }

    if (filters?.search) {
      const q = filters.search.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.productNameAr.toLowerCase().includes(q) ||
          p.productNameEn.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.storeOrSupplier.toLowerCase().includes(q) ||
          p.barcode.includes(q)
      );
    }

    if (filters?.category && filters.category !== 'all') {
      list = list.filter((p) => p.category === filters.category);
    }

    if (filters?.country && filters.country !== 'all') {
      list = list.filter(
        (p) =>
          p.countryCode.toLowerCase() === filters.country!.toLowerCase() ||
          p.countryNameEn.toLowerCase().includes(filters.country!.toLowerCase()) ||
          p.countryNameAr.includes(filters.country!)
      );
    }

    if (filters?.city && filters.city !== 'all') {
      list = list.filter((p) => p.city.toLowerCase().includes(filters.city!.toLowerCase()));
    }

    if (filters?.type && filters.type !== 'all') {
      list = list.filter((p) => p.supplierType === filters.type);
    }

    if (filters?.trend) {
      list = list.filter((p) => p.priceTrend === filters.trend);
    }

    return list;
  }

  public getProductById(id: string): ProductPrice | undefined {
    return this.products.find((p) => p.id === id);
  }

  public getProductsByBarcode(barcode: string): ProductPrice[] {
    return this.products.filter((p) => p.barcode === barcode.trim());
  }

  public getPriceComparison(productIdOrBarcode: string): ProductPrice[] {
    const matched = this.products.filter(
      (p) =>
        p.productId === productIdOrBarcode ||
        p.barcode === productIdOrBarcode ||
        p.id === productIdOrBarcode
    );
    return matched;
  }

  public addOrUpdatePrice(entry: Partial<ProductPrice> & { productNameAr: string; retailPrice: number }): ProductPrice {
    const existingIndex = this.products.findIndex(
      (p) =>
        (entry.id && p.id === entry.id) ||
        (p.barcode && entry.barcode && p.barcode === entry.barcode && p.storeOrSupplier === entry.storeOrSupplier)
    );

    const now = new Date().toISOString();
    if (existingIndex >= 0) {
      const existing = this.products[existingIndex];
      const prevRetail = existing.retailPrice;
      const changePct = prevRetail > 0 ? ((entry.retailPrice - prevRetail) / prevRetail) * 100 : 0;
      const trend = changePct < -0.5 ? 'down' : changePct > 0.5 ? 'up' : 'stable';

      const updated: ProductPrice = {
        ...existing,
        ...entry,
        priceTrend: trend,
        changePercentWeekly: Number(changePct.toFixed(2)),
        lastUpdated: now,
        history: [
          ...existing.history,
          {
            date: now.slice(0, 10),
            retailPrice: entry.retailPrice,
            wholesalePrice: entry.wholesalePrice ?? existing.wholesalePrice,
          },
        ],
      };
      this.products[existingIndex] = updated;
      this.checkAlerts(updated);
      this.save();
      return updated;
    } else {
      const newPrice: ProductPrice = {
        id: entry.id || `prod-${Date.now()}`,
        productId: entry.productId || `prod-custom-${Date.now()}`,
        productNameAr: entry.productNameAr,
        productNameEn: entry.productNameEn || entry.productNameAr,
        category: entry.category || 'grains',
        brand: entry.brand || 'عام',
        barcode: entry.barcode || `${Math.floor(100000000000 + Math.random() * 900000000000)}`,
        packageSize: entry.packageSize || '1 عبوة',
        weightGramsOrMl: entry.weightGramsOrMl || 1000,
        unit: entry.unit || 'kg',
        countryCode: entry.countryCode || 'SA',
        countryNameAr: entry.countryNameAr || 'المملكة العربية السعودية',
        countryNameEn: entry.countryNameEn || 'Saudi Arabia',
        city: entry.city || 'الرياض',
        storeOrSupplier: entry.storeOrSupplier || 'مورد معتمد',
        supplierType: entry.supplierType || 'wholesaler',
        retailPrice: entry.retailPrice,
        wholesalePrice: entry.wholesalePrice || entry.retailPrice * 0.9,
        minWholesaleQty: entry.minWholesaleQty || 10,
        wholesaleUnit: entry.wholesaleUnit || 'كرتون / عبوة',
        currency: entry.currency || 'SAR',
        shippingCost: entry.shippingCost || 0,
        sourceName: entry.sourceName || 'عرض مباشر من التاجر',
        sourceUrl: entry.sourceUrl || '#',
        verified: entry.verified ?? true,
        lastUpdated: now,
        priceTrend: 'stable',
        changePercentWeekly: 0,
        history: [
          {
            date: now.slice(0, 10),
            retailPrice: entry.retailPrice,
            wholesalePrice: entry.wholesalePrice || entry.retailPrice * 0.9,
          },
        ],
        inStock: true,
        imageUrl: entry.imageUrl || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80',
      };
      this.products.unshift(newPrice);
      this.save();
      return newPrice;
    }
  }

  // --- Price Alerts ---
  public addAlert(alert: Omit<PriceAlert, 'id' | 'createdAt' | 'isActive'>): PriceAlert {
    const newAlert: PriceAlert = {
      ...alert,
      id: `alert-${Date.now()}`,
      isActive: true,
      createdAt: new Date().toISOString(),
    };
    this.alerts.unshift(newAlert);
    this.save();
    return newAlert;
  }

  public getAlerts(userId: string): PriceAlert[] {
    return this.alerts.filter((a) => a.userId === userId);
  }

  public deleteAlert(alertId: string, userId: string): boolean {
    const initialLen = this.alerts.length;
    this.alerts = this.alerts.filter((a) => !(a.id === alertId && a.userId === userId));
    this.save();
    return this.alerts.length < initialLen;
  }

  private checkAlerts(product: ProductPrice) {
    for (const alert of this.alerts) {
      if (alert.isActive && (alert.productId === product.productId || alert.productName === product.productNameAr)) {
        if (alert.direction === 'below' && product.retailPrice <= alert.targetPrice) {
          alert.triggeredAt = new Date().toISOString();
        }
      }
    }
  }

  // --- Users & Auth ---
  public getUsers(): UserAccount[] {
    return this.users;
  }

  public getUserByEmail(email: string): UserAccount | undefined {
    return this.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public getUserById(id: string): UserAccount | undefined {
    return this.users.find((u) => u.id === id);
  }

  public createUser(userData: {
    name: string;
    email: string;
    password: string;
    role?: UserAccount['role'];
    country?: string;
    city?: string;
    companyName?: string;
  }): UserAccount {
    const existing = this.getUserByEmail(userData.email);
    if (existing) {
      throw new Error('User email already registered');
    }
    const newUser: UserAccount = {
      id: `user-${Date.now()}`,
      name: userData.name,
      email: userData.email,
      passwordHash: userData.password,
      role: userData.role || 'customer',
      country: userData.country || 'Saudi Arabia',
      city: userData.city || 'الرياض',
      companyName: userData.companyName,
      isVerifiedSupplier: userData.role === 'supplier' || userData.role === 'retailer',
      createdAt: new Date().toISOString(),
      walletBalance: { SAR: 1000, USD: 250, YER: 150000, EGP: 5000 },
    };
    this.users.push(newUser);
    this.save();
    return newUser;
  }

  public deleteUser(userId: string): boolean {
    const len = this.users.length;
    this.users = this.users.filter((u) => u.id !== userId);
    this.save();
    return this.users.length < len;
  }

  // --- Wallet Operations ---
  public getWallet(userId: string) {
    const user = this.getUserById(userId);
    const txs = this.transactions.filter((t) => t.userId === userId);
    return {
      userId,
      balances: user ? user.walletBalance : { SAR: 0, USD: 0, YER: 0, EGP: 0 },
      transactions: txs,
      isDemo: true,
      demoNote: 'رصيد محاكاة تجريبي لتطبيق WORLD MARKET AI',
    };
  }

  public executeTransfer(params: {
    senderId: string;
    recipientEmail: string;
    amount: number;
    currency: string;
    note: string;
  }): WalletTransaction {
    const sender = this.getUserById(params.senderId);
    if (!sender) throw new Error('Sender not found');

    const currentBalance = sender.walletBalance[params.currency] || 0;
    const fee = 0; // Demo zero fee
    if (currentBalance < params.amount + fee) {
      throw new Error(`رصيد ${params.currency} غير كافٍ لإتمام التحويل`);
    }

    // Deduct from sender
    sender.walletBalance[params.currency] = currentBalance - (params.amount + fee);

    // Credit recipient if in DB
    const recipient = this.getUserByEmail(params.recipientEmail);
    if (recipient) {
      recipient.walletBalance[params.currency] = (recipient.walletBalance[params.currency] || 0) + params.amount;
    }

    const tx: WalletTransaction = {
      id: `tx-${Date.now()}`,
      userId: params.senderId,
      recipientEmail: params.recipientEmail,
      recipientName: recipient ? recipient.name : params.recipientEmail,
      type: 'transfer_out',
      amount: params.amount,
      fee,
      currency: params.currency,
      status: 'completed',
      referenceNote: params.note || 'تحويل تجريبي عبر محفظة WORLD WALLET',
      timestamp: new Date().toISOString(),
    };

    this.transactions.unshift(tx);
    this.save();
    return tx;
  }

  public topUpDemoWallet(userId: string, currency: string, amount: number): number {
    const user = this.getUserById(userId);
    if (!user) throw new Error('User not found');
    user.walletBalance[currency] = (user.walletBalance[currency] || 0) + amount;

    this.transactions.unshift({
      id: `tx-${Date.now()}`,
      userId,
      type: 'demo_deposit',
      amount,
      fee: 0,
      currency,
      status: 'completed',
      referenceNote: `شحن رصيد تجريبي إضافي (${amount} ${currency})`,
      timestamp: new Date().toISOString(),
    });
    this.save();
    return user.walletBalance[currency];
  }

  // --- Data Sources Status ---
  public getDataSources(): DataSourceStatus[] {
    return this.dataSources;
  }

  public triggerSyncSource(id: string): DataSourceStatus | undefined {
    const src = this.dataSources.find((s) => s.id === id);
    if (src) {
      src.lastSync = new Date().toISOString();
      src.latencyMs = Math.floor(40 + Math.random() * 80);
      src.status = 'online';
      this.save();
    }
    return src;
  }

  // --- Misleading Price Reports ---
  public reportMisleadingPrice(report: Omit<MisleadingPriceReport, 'id' | 'createdAt' | 'status'>): MisleadingPriceReport {
    const newReport: MisleadingPriceReport = {
      ...report,
      id: `rep-${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    this.reports.unshift(newReport);
    this.save();
    return newReport;
  }

  public getReports(): MisleadingPriceReport[] {
    return this.reports;
  }
}

export const db = new DatabaseEngine();
